// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MyHelloServiceImpl.java

package com.dess.cq.common.services.impl;

import com.dess.cq.common.services.MyHelloService;
import org.apache.sling.jcr.api.SlingRepository;

public class MyHelloServiceImpl
    implements MyHelloService
{

    public MyHelloServiceImpl()
    {
    }

    public String getRepositoryName()
    {
        return repository.getDescriptor("jcr.repository.name");
    }

    protected void bindRepository(SlingRepository paramSlingRepository)
    {
        repository = paramSlingRepository;
    }

    protected void unbindRepository(SlingRepository paramSlingRepository)
    {
        if(repository == paramSlingRepository)
            repository = null;
    }

    private SlingRepository repository;
}
