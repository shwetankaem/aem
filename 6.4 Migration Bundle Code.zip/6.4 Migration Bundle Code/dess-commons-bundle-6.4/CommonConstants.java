// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonConstants.java

package com.dess.cq.common;


public final class CommonConstants
{

    public CommonConstants()
    {
    }

    public static final String UNSTRUCTURED_NODE = "nt:unstructured";
    public static final String RESOURCE_TYPE = "sling:resourceType";
    public static final String SUB_NAV_RESOURCE_TYPE = "paw/components/content/commons/subnavigation";
    public static final String COMPONENT = "component";
    public static final String PREDICATE_PATH = "path";
    public static final String PREDICATE_OFFSET = "p.offset";
    public static final String PREDICATE_LIMIT = "p.limit";
    public static final String PREDICATE_ORDERBY_SORT = "orderby.sort";
    public static final String PREDICATE_ORDERBY = "orderby";
    public static final String PREDICATE_CQ_TAGS = "jcr:content/cq:tags";
    public static final String PREDICATE_CQ_TAGS_DAM = "jcr:content/metadata/cq:tags";
    public static final String PREDICATE_DESC = "desc";
    public static final String PREDICATE_SORT_DATE_PROPERTY = "@jcr:content/cq:lastReplicated";
    public static final String PREDICATE_CQ_PAGE = "cq:Page";
    public static final String PREDICATE_DAM_ASSET = "dam:Asset";
    public static final String PREDICATE_TYPE = "type";
    public static final String PREDICATE_FULLTEXT = "fulltext";
    public static final String DEFAULT_OFFSET_VALUE = "0";
    public static final String DEFAULT_LIMIT_VALUE = "25";
    public static final String PREDICATE_GROUP1_OR = "1_group.p.or";
    public static final String PREDICATE_VALUE_TRUE = "true";
    public static final String JCR_PRIMARY_TYPE = "jcr:primaryType";
    public static final String DAM_ASSET_CONTENT = "dam:AssetContent";
    public static final String COMMON_TAG_NAMESPACE = "/etc/tags";
    public static final String JCR_CONTENT = "jcr:content";
    public static final String PROPERTY = "property";
    public static final String PREDICATE_ORDER_INDEX = "orderby.index";
    public static final String TRUE_STRING = "true";
    public static final String PREDICATE_GROUP_1_GROUP_1_TAGID = "1_group.1_group.1_tagid";
    public static final String PREDICATE_GROUP_1_GROUP_1 = "1_group.1_group.";
    public static final String PREDICATE_GROUP_1_GROUP_2 = "1_group.2_group.";
    public static final String PREDICATE_TAGID_PROPERTY = "_tagid.property";
    public static final String PREDICATE_TAGID = "_tagid";
    public static final int CONVERSION_FACTOR = 1024;
    public static final String ASSET_TITLE = "dc:title";
    public static final String ASSET_DESCRIPTION = "dc:description";
    public static final String EMPTY_STRING = "";
    public static final int SIZE_ONE = 1;
    public static final String PREDICATE_PROPERTY_VALUE = "property.value";
    public static final String PROPERTY_OPERATION = "property.operation";
    public static final String SLASH_FORWARD = "/";
    public static final String LINK_TARGET_OPTIONS = "linkTargetOptions";
    public static final String OPENMODAL = "openamodal";
    public static final String EXISTS = "exists";
    public static final String IFRAMEID = "iframeid";
    public static final String MENU_LINKS = "menulinks";
    public static final String ITEM_URL = "itemurl";
    public static final String SECTION_GATEWAY_CSS = "sectiongatewaycss";
    public static final String IMAGERY_RESOURCE_PATH = "desscommon/components/imagery";
    public static final String PANEL_RESOURCE_PATH = "desscommon/components/panels";
}
