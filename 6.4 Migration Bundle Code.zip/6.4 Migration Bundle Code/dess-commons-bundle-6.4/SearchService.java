// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SearchService.java

package com.dess.cq.common.search;

import com.dess.cq.common.search.models.CommonSearchRequest;
import com.dess.cq.common.search.models.CommonSearchResultWrapper;
import javax.jcr.RepositoryException;

public interface SearchService
{

    public abstract CommonSearchResultWrapper getResults(CommonSearchRequest commonsearchrequest)
        throws RepositoryException;
}
