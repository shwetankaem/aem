<%--

  Set End Time Utility for all chosen page path  component.

  This Utility sets the offTime property on all the pages under the chosen page path in the dialoq.


--%><%
%><%@include file="/libs/foundation/global.jsp"%><%
%><%@page session="false" %>
<%@page import="java.util.Calendar,com.day.cq.search.PredicateGroup,com.day.cq.search.result.SearchResult,java.text.SimpleDateFormat,java.text.DateFormat,java.util.Date,java.util.Iterator,com.day.cq.search.Query,com.day.cq.search.QueryBuilder,java.util.Map,java.util.HashMap" %><%
%><%
	// TODO add you code here
%>

<%
   Session session = resource.getResourceResolver().adaptTo(Session.class);
   String itemType =  properties.get("itemType","pages");
   String pagePath =  properties.get("pagePath",currentPage.getPath());
   Date date = properties.get("offTime",Date.class);
   DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
if(date!=null) {
   String stringDate = df.format(date);
   Calendar cal = Calendar.getInstance();
   cal.setTime(date);
   Map<String,String> map = new HashMap<String,String>();
   if(itemType.equalsIgnoreCase("pages")) {
    map.put("type","cq:PageContent");
   } else {
     map.put("type","dam:AssetContent");
   }
   map.put("path",pagePath);
   map.put("p.limit","-1");
   QueryBuilder queryBuilder = sling.getService(QueryBuilder.class);
   Query query =  queryBuilder.createQuery(PredicateGroup.create(map),session);
   SearchResult searchResult = query.getResult();
	if (searchResult != null) {

			Iterator<Node> iterator = searchResult.getNodes();
        	Node resultNode = null; 

        while(iterator.hasNext()) {

             resultNode = (Node)iterator.next();
             resultNode.setProperty("offTime" ,cal);
             session.save();
        }
    }

    %>
 The selected page Path is <%= pagePath%> and the selected offTime is set at <%= stringDate %>
<%
} else {

%>

Edit the dialog to select the page path and the Offtime date

<% }%>