// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FooterLinksUse.java

package com.icicipru.components.model;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Referenced classes of package com.icicipru.components.model:
//            FooterLinks

public class FooterLinksUse extends WCMUsePojo
{

    public FooterLinksUse()
    {
    }

    public void activate()
        throws Exception
    {
        LOGGER.info("FooterLinksUSE STARTS");
        Page homePage = getHomePage(getCurrentPage());
        if(homePage != null)
        {
            Resource footerResource = homePage.getContentResource("footer");
            if(footerResource != null)
                footerLinks = (FooterLinks)footerResource.adaptTo(com/icicipru/components/model/FooterLinks);
        }
    }

    private Page getHomePage(Page current)
    {
_L2:
        if(current == null)
            break; /* Loop/switch isn't completed */
        String pageTemplate = (String)current.getProperties().get("cq:template", "");
        if("/apps/icicipru/templates/homepage".equals(pageTemplate))
            return current;
        try
        {
            current = current.getParent();
            continue; /* Loop/switch isn't completed */
        }
        catch(Exception exception) { }
        break; /* Loop/switch isn't completed */
        if(true) goto _L2; else goto _L1
_L1:
        return null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/components/model/FooterLinks);
    public static final String HOME_PAGE_TEMPLATE_PATH = "/apps/icicipru/templates/homepage";
    public FooterLinks footerLinks;

}
