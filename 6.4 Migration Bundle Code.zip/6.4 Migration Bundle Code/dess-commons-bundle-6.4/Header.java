// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Header.java

package com.dess.cq.common.models;

import com.dess.cq.common.helper.JcrQueryBuilder;
import com.dess.cq.common.utilities.CommonUtility;
import java.util.Date;
import java.util.Map;
import javax.jcr.*;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateMidnight;
import org.osgi.framework.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Header
{

    public Header()
    {
    }

    public static boolean isDownTimeNotificationActive(Date startTime, Date endTime)
    {
        boolean isActive = false;
        DateMidnight currentTimeCheck = new DateMidnight();
        DateMidnight startTimeCheck = new DateMidnight(startTime.getTime());
        DateMidnight endTimeCheck = new DateMidnight(endTime.getTime());
        if(currentTimeCheck.isAfter(startTimeCheck) && currentTimeCheck.isBefore(endTimeCheck))
            isActive = true;
        return isActive;
    }

    public static String getSectionGatewayCssClass(Session session, String currentPagePath, String searchPath, String resourcePath, boolean inheritParentStyle)
    {
        JcrQueryBuilder jcrQueryBuilder;
        BundleContext bundleContext = FrameworkUtil.getBundle(com/dess/cq/common/helper/JcrQueryBuilder).getBundleContext();
        org.osgi.framework.ServiceReference factoryRef = bundleContext.getServiceReference(com/dess/cq/common/helper/JcrQueryBuilder.getName());
        jcrQueryBuilder = (JcrQueryBuilder)bundleContext.getService(factoryRef);
        int index;
        Value avalue[];
        int i;
        int j;
        Node node = jcrQueryBuilder.getDialogInfoNode(session, searchPath, resourcePath);
        if(null == node)
            break MISSING_BLOCK_LABEL_232;
        Property menuLinksProperty = node.getProperty("menulinks");
        Value menuLinkValues[] = menuLinksProperty.getValues();
        index = 0;
        avalue = menuLinkValues;
        i = avalue.length;
        j = 0;
_L1:
        Map map;
        String gatewayPagePath;
        if(j >= i)
            break MISSING_BLOCK_LABEL_232;
        Value menuLinkValue = avalue[j];
        map = CommonUtility.jsonStringToMap(menuLinkValue.getString());
        if(!map.containsKey("itemurl"))
            break MISSING_BLOCK_LABEL_203;
        gatewayPagePath = (String)map.get("itemurl");
        if(!StringUtils.isNotEmpty(currentPagePath))
            break MISSING_BLOCK_LABEL_203;
        if(currentPagePath.trim().equals(gatewayPagePath))
            return (String)map.get("sectiongatewaycss");
        if(isChildPageToInheritParentStyle(currentPagePath, inheritParentStyle, index, gatewayPagePath))
            return (String)map.get("sectiongatewaycss");
        index++;
        j++;
          goto _L1
        RepositoryException repositoryException;
        repositoryException;
        LOGGER.error("Exception while Retrieving Section gateway CSS class : {}", repositoryException.getMessage());
        return "";
    }

    private static boolean isChildPageToInheritParentStyle(String currentPagePath, boolean inheritParentStyle, int index, String gatewayPagePath)
    {
        return currentPagePath.trim().contains(gatewayPagePath) && index > 0 && inheritParentStyle;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/models/Header);

}
