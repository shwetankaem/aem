<%-- dialogpoc component. --%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@ page import="com.day.cq.wcm.foundation.Placeholder" %>
<%@taglib prefix="dess" uri="http://dess.co.in/desscommon"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>
<dess:cleanHTMLFragment>
    <c:choose>
        <c:when test="${fn:length(properties.headertag) > 0}">
            
            <c:if test="${properties.headingactivateid}">
                <c:set var="idHeader" value="id=\"${properties.headerid}\""/>
            </c:if>
            <c:if test="${not empty properties.text}">
            	<${properties.headertag} ${idHeader} class="${properties.size} ${properties.classappend}"><cq:text property="text" placeholder="<%= Placeholder.getDefaultPlaceholder(slingRequest, component, null)%>"/></${properties.headertag}>
            </c:if>                
        </c:when>
        <c:otherwise>
            <%if(WCMMode.fromRequest(request) == WCMMode.EDIT){%> 
            	<h4>Edit Headings</h4>
            <%}%>
        </c:otherwise>
    </c:choose> 
</dess:cleanHTMLFragment>