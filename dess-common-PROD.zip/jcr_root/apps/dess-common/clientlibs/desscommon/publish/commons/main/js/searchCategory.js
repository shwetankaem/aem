$.fn.searchcat = function () {
    $("#jsSearchByCat").on("change",".form-control",function(){
        $.fn.controllformcontrol(this);
    });
};

$.fn.controllformcontrol = function (thisel) {
    var childrenof = thisel.value;
    var addnextto = $(thisel).parents(".form-group");
    var selPrdctformgroup=$("#selectProductType").parents(".form-group");
    var resultHeader = $("#jsResultsHeader");
    var resultList = $("#resultsList");
    var pagination = $(".search-category-results ul.pager");
    var loader = $("#jsLoadingSpinner");
    var resultBtn = $("#jsResultsButton");


    var headerTemplate = $.fn.getcompiledtemplate("#search-header-template");
    var resultsTemplate = $.fn.getcompiledtemplate("#search-results-template");
    var pagerTemplate = $.fn.getcompiledtemplate("#search-pager-template");
    var selProdVal=$("#selectProduct").val();
    if(childrenof=="all"){
        childrenof=$(addnextto).prev().find("select").val();
        $(addnextto).nextAll(".form-group").has("select.form-control").remove();
    }

    if(thisel.id!="selectProduct"){
      $(addnextto).nextAll(".form-group").has("select.form-control").remove();
    }else{
        $('#selectProductType').val("all");
    	$(selPrdctformgroup).nextAll(".form-group").has("select.form-control").remove();
    }

    resultHeader.empty();
    resultList.empty();
    pagination.empty();
    loader.addClass("hidden");
    resultBtn.addClass("disabled");

    $("#jsResultsButton > span.icon").removeClass("icon-arrow-right").addClass("icon-progress");
    $("#jsResultsButton > span.result-amount").text("(fetching results available)");

	if(thisel.id!="selectProduct" && thisel.value!="all"){

        var url = $("#currentnodepath").val();
        url = url + ".children.json" + "?tagID=" + childrenof;



    $.ajax({
        url: url,
        type: "get",
        dataType: "json",
        success: function (responseText) {
            if(responseText) {
                var template = $.fn.getcompiledtemplate("#search-category");
                $(template(responseText)).insertAfter(addnextto);
            }
        }
    }); 

    }

    var urll = document.URL;
	var secTag = childrenof?childrenof:"";
    var urlWithoutparameters = urll.substring(0,urll.indexOf("?"));
    urlWithoutparameters = urlWithoutparameters.substring(0, urlWithoutparameters.length - 5);
    var searchUrl = urlWithoutparameters+".search.html?selectArea="+$("#contentpath").val()+"&sectionTag="+ secTag +"&limit="+$("#listcount").val()+"&offset=0"+
            "&locationTag="+selProdVal;
    
    $.ajax({
        url: searchUrl,
        type: "get",
        dataType: "json",
        success: function (responseText) {
            if(responseText) {
                resultBtn.removeClass("disabled");
                $("#jsResultsButton > span.icon").removeClass("icon-progress").addClass("icon-arrow-right");
               
                if(responseText && responseText.totalMatches){
                    $("#jsResultsButton > span.result-amount").text("(" +responseText.totalMatches+" results available)");
                    resultBtn.on("click",function(e) {  
                        e.preventDefault();
                        loader.removeClass("hidden");
                        resultHeader.html($(headerTemplate(responseText)));
                        resultList.html($(resultsTemplate(responseText)));
                        pagination.html($(pagerTemplate(responseText)));
                        loader.addClass("hidden");
                    });

                    $(".search-category-results").on("click", ".pager li.next a" , function(e) {
                        e.preventDefault();
                        var nextAjaxURL = $(this).attr('href');
                        
                        $.ajax({
                            url: nextAjaxURL,
                            type: "get",
                            dataType: "json",
                            success: function (data) {
                                if(data!=null && data!= "") {
                                    resultHeader.html($(headerTemplate(data)));
                                    resultList.html($(resultsTemplate(data)));
                                    pagination.html($(pagerTemplate(data)));
                                }
                            }
                        });
                    }); 
                    
                    $(".search-category-results").on("click", ".pager li.previous a" , function(e) {
                        e.preventDefault();
                        var previousAjaxUrl = $(this).attr('href');
                        $.ajax({
                            url: previousAjaxUrl,
                            type: "get",
                            dataType: "json",
                            success: function (data) {
                                if(data!=null && data!= "") {
                                    resultHeader.html($(headerTemplate(data)));
                                    resultList.html($(resultsTemplate(data)));
                                    pagination.html($(pagerTemplate(data)));
                                }
                            }
                        });
                    });
                } else {
                		resultBtn.addClass("disabled");
                        $("#jsResultsButton > span.result-amount").text("( 0 results available)");
                }
            } else {
                resultBtn.addClass("disabled");
                $("#jsResultsButton > span.result-amount").text("( 0 results available)");
            }
        }
    });
};

$.fn.getcompiledtemplate = function (templateIdSelector) {
    var headerSource   = $(templateIdSelector).html();
    return Handlebars.compile(headerSource);
};

$( document ).ready(function() {
    $('#selectProduct').exists(function() {
        $.fn.controllformcontrol($("#selectProduct").val());
    });
    $.fn.searchcat();
});