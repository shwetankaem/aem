// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CleanHTMLFragment.java

package com.dess.cq.common.utilities;

import java.io.IOException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CleanHTMLFragment extends BodyTagSupport
{

    public CleanHTMLFragment()
    {
    }

    public void setBodyContent(BodyContent bc)
    {
        super.setBodyContent(bc);
    }

    public int doAfterBody()
    {
        try
        {
            BodyContent bodyContent = super.getBodyContent();
            String bodyString = bodyContent.getString();
            String attributesToCheck = "id|class";
            JspWriter out = bodyContent.getEnclosingWriter();
            out.print(cleanHtmlFragment(bodyString, "id|class"));
            bodyContent.clear();
        }
        catch(IOException ioException)
        {
            LOGGER.error("Unable to clean HTML Fragment :: {}", ioException.getMessage());
        }
        return 0;
    }

    private static String cleanHtmlFragment(String htmlFragment, String attributesToCheck)
    {
        return htmlFragment.replaceAll("=+\\s*\"\\s+", "=\"").replaceAll("\\s+\"", "\"").replaceAll((new StringBuilder()).append("\\s+(?:").append(attributesToCheck).append(")\\s*=\\s*\"\\s*\"").toString(), "").replaceAll("\\s+", " ");
    }

    private static final long serialVersionUID = 0x8d50917e46ab079fL;
    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/utilities/CleanHTMLFragment);

}
