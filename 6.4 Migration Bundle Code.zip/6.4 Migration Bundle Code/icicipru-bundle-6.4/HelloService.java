// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HelloService.java

package com.icicipru.core;


public interface HelloService
{

    public abstract String getRepositoryName();
}
