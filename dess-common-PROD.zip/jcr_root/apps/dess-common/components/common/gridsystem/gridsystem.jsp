<%--

  gridsystem component.



--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%><%
%><%@page session="false" %>

<%if(WCMMode.fromRequest(request) == WCMMode.EDIT){%> 
<cq:includeClientLib categories="author.dess.common.components.gridsystem"/>
<%}%> 


<cq:include script="layout.jsp" />
