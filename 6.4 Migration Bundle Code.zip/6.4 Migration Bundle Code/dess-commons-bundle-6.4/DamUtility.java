// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DamUtility.java

package com.dess.cq.common.utilities;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DamUtility
{

    public DamUtility()
    {
    }

    public static double getDamFileSize(String filePath, ResourceResolver resourceResolver)
    {
        double fileSize = 0.0D;
        if(StringUtils.isNotBlank(filePath) && resourceResolver != null)
        {
            Resource fileResource = resourceResolver.getResource(filePath);
            if(fileResource != null)
            {
                Asset asset = (Asset)fileResource.adaptTo(com/day/cq/dam/api/Asset);
                if(asset.getOriginal() != null)
                    fileSize = asset.getOriginal().getSize() / 1024L;
            }
        }
        LOGGER.debug("File size is {} :", Double.valueOf(fileSize));
        return fileSize;
    }

    public static String getDamFileSizeWithUnit(String filePath, ResourceResolver resourceResolver)
    {
        StringBuilder strBuilder = new StringBuilder();
        if(StringUtils.isNotBlank(filePath))
        {
            double fileSize = getDamFileSize(filePath, resourceResolver);
            if(fileSize < 1024D)
            {
                strBuilder.append((double)Math.round(fileSize * 100D) / 100D);
                strBuilder.append("KB");
            } else
            {
                fileSize /= 1024D;
                strBuilder.append((double)Math.round(fileSize * 100D) / 100D);
                strBuilder.append("MB");
            }
        }
        LOGGER.debug("File size with units is {} :", strBuilder.toString());
        return strBuilder.toString();
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/utilities/DamUtility);
    private static final String UNIT_KB = "KB";
    private static final String UNIT_MB = "MB";
    private static final int BYTE_BASE = 1024;
    private static final double ROUND_OFF_FACTOR = 100D;

}
