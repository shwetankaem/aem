// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SocialLinks.java

package com.icicipru.sightly.bean;


public class SocialLinks
{

    public String getNavigationURL()
    {
        return navigationURL;
    }

    public void setNavigationURL(String navigationURL)
    {
        this.navigationURL = navigationURL;
    }

    public String getCssSelect()
    {
        return cssSelect;
    }

    public void setCssSelect(String cssSelect)
    {
        this.cssSelect = cssSelect;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public SocialLinks(String title, String navigationURL, String cssSelect)
    {
        this.title = title;
        this.navigationURL = navigationURL;
        this.cssSelect = cssSelect;
    }

    public SocialLinks()
    {
    }

    private String title;
    private String navigationURL;
    private String cssSelect;
}
