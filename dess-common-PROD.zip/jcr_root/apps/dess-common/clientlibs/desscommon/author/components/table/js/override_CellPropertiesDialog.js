(function() {
    var originalCalculateCellConfig = CQ.form.rte.plugins.CellPropertiesDialog.prototype.calculateCellConfig;
    CQ.Ext.override(CQ.form.rte.plugins.CellPropertiesDialog,{
	calculateCellConfig: function() {
     if(this.editContext.iFrame?this.editContext.iFrame.getAttribute("configuredforcommon"):""){
     var com = CUI.rte.Common;
        var cellConfig = { };
        this.propertyItems.each(function(item) {
            var id = item.itemId;
            if (id == "cellStyle") {
                var styleCnt = this.cellStyles.length;
                var classNames = com.parseCSS(this.cell);
                var isFound = false;
                for (var i = 0; (i < classNames.length) && !isFound; i++) {
                    for (var s = 0; s < styleCnt; s++) {
                        var style = this.cellStyles[s];
                        if (style.cssName == classNames[i]) {
                            cellConfig[id] = classNames[i];
                            isFound = true;
                            break;
                        }
                    }
                }
            }else{
                if (item.styleAttrib) {
                    if (this.cell.style[item.styleAttrib]) {
                        cellConfig[id] = this.cell.style[item.styleAttrib];
                    }
                } else {
                    var propName = item.domProp || id;
                    var olength=item.options ? item.options.length : "";
					if(propName=='width' || propName=='height')
                    {
                        item.setVisible(false);
                    }
                    if(propName=='valign' && olength && item.options[olength-1].value=='baseline')
					{
					item.options.pop();
                    item.setOptions(item.options);
                    }
                    if (com.isAttribDefined(this.cell, propName)) {
                        cellConfig[id] = com.getAttribute(this.cell, propName);
                    }
                } 
            }
            return true;
        }, this);
        return cellConfig;
    }else{
	originalCalculateCellConfig.apply(this);
    }
	}
});
}());