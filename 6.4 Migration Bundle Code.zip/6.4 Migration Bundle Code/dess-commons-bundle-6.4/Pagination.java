// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Pagination.java

package com.dess.cq.common.search.models;


public class Pagination
{

    public Pagination()
    {
    }

    public long getTotalMatches()
    {
        return totalMatches;
    }

    public void setTotalMatches(long totalMatches)
    {
        this.totalMatches = totalMatches;
    }

    public long getHitsPerPage()
    {
        return hitsPerPage;
    }

    public void setHitsPerPage(long hitsPerPage)
    {
        this.hitsPerPage = hitsPerPage;
    }

    public int getHitsCount()
    {
        return hitsCount;
    }

    public void setHitsCount(int hitsCount)
    {
        this.hitsCount = hitsCount;
    }

    public int getCurrentPageIndex()
    {
        return currentPageIndex;
    }

    public void setCurrentPageIndex(int currentPageIndex)
    {
        this.currentPageIndex = currentPageIndex;
    }

    public int getTotalPages()
    {
        return totalPages;
    }

    public void setTotalPages(int totalPages)
    {
        this.totalPages = totalPages;
    }

    public String getNextPageAjaxUrl()
    {
        return nextPageAjaxUrl;
    }

    public void setNextPageAjaxUrl(String nextPageAjaxUrl)
    {
        this.nextPageAjaxUrl = nextPageAjaxUrl;
    }

    public String getPreviousPageAjaxUrl()
    {
        return previousPageAjaxUrl;
    }

    public void setPreviousPageAjaxUrl(String previousPageAjaxUrl)
    {
        this.previousPageAjaxUrl = previousPageAjaxUrl;
    }

    public boolean isDisablePrevButton()
    {
        return disablePrevButton;
    }

    public void setDisablePrevButton(boolean disablePrevButton)
    {
        this.disablePrevButton = disablePrevButton;
    }

    public boolean isDisableNextButton()
    {
        return disableNextButton;
    }

    public void setDisableNextButton(boolean disableNextButton)
    {
        this.disableNextButton = disableNextButton;
    }

    public String getSingularResult()
    {
        return singularResult;
    }

    public void setSingularResult(String singularResult)
    {
        this.singularResult = singularResult;
    }

    private long totalMatches;
    private long hitsPerPage;
    private int hitsCount;
    private int currentPageIndex;
    private int totalPages;
    private String nextPageAjaxUrl;
    private String previousPageAjaxUrl;
    private boolean disablePrevButton;
    private boolean disableNextButton;
    private String singularResult;
}
