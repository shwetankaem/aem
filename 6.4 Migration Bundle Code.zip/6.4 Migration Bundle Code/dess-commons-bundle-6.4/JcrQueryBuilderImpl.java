// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JcrQueryBuilderImpl.java

package com.dess.cq.common.helper.impl;

import com.day.cq.search.*;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.dess.cq.common.helper.JcrQueryBuilder;
import java.util.*;
import javax.jcr.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JcrQueryBuilderImpl
    implements JcrQueryBuilder
{

    public JcrQueryBuilderImpl()
    {
    }

    public SearchResult getResults(Map map, Session session)
    {
        Query query = createQuery(map, session);
        return executeQuery(query);
    }

    public SearchResult getResults(Map map, Session session, long startIndex, long endIndex)
    {
        Query query = createQuery(map, session);
        query.setStart(startIndex);
        query.setHitsPerPage(endIndex);
        return executeQuery(query);
    }

    private Query createQuery(Map map, Session session)
    {
        return queryBuilder.createQuery(PredicateGroup.create(map), session);
    }

    private SearchResult executeQuery(Query query)
    {
        return query.getResult();
    }

    public List getResultNodes(SearchResult searchResult)
        throws RepositoryException
    {
        List nodeList = new ArrayList();
        for(Iterator iterator = searchResult.getHits().iterator(); iterator.hasNext();)
        {
            Hit hit = (Hit)iterator.next();
            try
            {
                Node parentNode = hit.getNode();
                nodeList.add(parentNode);
            }
            catch(ItemNotFoundException itemNotFoundException)
            {
                LOGGER.error("Item Not Found Exception during getting node from hit :: {}", itemNotFoundException.getMessage());
            }
        }

        return nodeList;
    }

    public long getCurrentPageModals(String searchPath, Session session)
    {
        long totalMatches = 0L;
        Map map = new HashMap();
        StringBuilder strBuild = new StringBuilder();
        strBuild.append(searchPath);
        strBuild.append("/");
        strBuild.append("jcr:content");
        map.put("path", strBuild.toString());
        map.put("property", "linkTargetOptions");
        map.put("property.value", "openamodal");
        SearchResult searchResult = getResults(map, session);
        totalMatches = searchResult.getTotalMatches();
        return totalMatches;
    }

    public List getCurrentPageIframe(String searchPath, Session session)
    {
        Map map = new HashMap();
        map.put("path", searchPath);
        map.put("type", "nt:unstructured");
        map.put("property", "iframeid");
        map.put("property.operation", "exists");
        SearchResult searchResult = getResults(map, session);
        LOGGER.info("***************************  BEFORE QUERY********************");
        Iterator nodeItr = searchResult.getNodes();
        LOGGER.info("***************************  AFTER QUERY********************");
        List iframelist = new ArrayList();
        if(nodeItr != null)
            do
            {
                if(!nodeItr.hasNext())
                    break;
                try
                {
                    Node node = (Node)nodeItr.next();
                    if(node != null && node.hasProperty("iframeid"))
                        iframelist.add(node.getProperty("iframeid").getString());
                }
                catch(ValueFormatException valueFormatException)
                {
                    LOGGER.error("Exception while Retrieving Current Page Iframe : {}", valueFormatException.getMessage());
                }
                catch(PathNotFoundException pathNotFoundException)
                {
                    LOGGER.error("Exception while Retrieving Current Page Iframe : {}", pathNotFoundException.getMessage());
                }
                catch(RepositoryException repositoryException)
                {
                    LOGGER.error("Exception while Retrieving Current Page Iframe : {}", repositoryException.getMessage());
                }
            } while(true);
        return iframelist;
    }

    public boolean isResourceAvailInCurrentPage(String currentPagePath, String resourcePath, Session session)
    {
        boolean isAvailable = false;
        long totalMatches = 0L;
        Map map = new HashMap();
        StringBuilder strBuild = new StringBuilder();
        strBuild.append(currentPagePath);
        strBuild.append("/");
        strBuild.append("jcr:content");
        map.put("path", strBuild.toString());
        map.put("property", "sling:resourceType");
        map.put("property.value", resourcePath);
        SearchResult searchResult = getResults(map, session);
        totalMatches = searchResult.getTotalMatches();
        if(totalMatches > 0L)
            isAvailable = true;
        return isAvailable;
    }

    public Node getDialogInfoNode(Session session, String pagePath, String resourcePath)
    {
        Node contactUsNode = null;
        Map map = new HashMap();
        map.put("path", pagePath);
        map.put("property", "sling:resourceType");
        map.put("property.value", resourcePath);
        try
        {
            SearchResult aSearchResult = getResults(map, session);
            List nodes = getResultNodes(aSearchResult);
            if(nodes != null && !nodes.isEmpty())
                contactUsNode = (Node)nodes.get(0);
        }
        catch(RepositoryException repositoryException)
        {
            LOGGER.error("Exception while Retrieving Dialog Information : {}", repositoryException.getMessage());
        }
        return contactUsNode;
    }

    protected void bindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        queryBuilder = paramQueryBuilder;
    }

    protected void unbindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        if(queryBuilder == paramQueryBuilder)
            queryBuilder = null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/helper/impl/JcrQueryBuilderImpl);
    private QueryBuilder queryBuilder;

}
