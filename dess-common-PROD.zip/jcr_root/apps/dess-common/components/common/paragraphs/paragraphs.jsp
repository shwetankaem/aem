<%--
	Paragraphs component.
--%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@ page import="com.day.cq.wcm.foundation.Placeholder" %>
<%@page session="false" %>
<%
String text = properties.get("text", "");
if(text != "" && text.indexOf("<p>") != 0){
        text = "<p>"+text+"</p>";
} 
%>
<dess:cleanHTMLFragment>
    <c:choose>
        <c:when test="${fn:length(properties.text) > 0}">
            <c:set var="paraText" value="<%=text%>" />
            <c:set var="paraTag" value="<p class=\"${properties.classoverride} ${properties.showonprintpara eq 'true'?'':'hidden-print'}\">" />
            	${fn:replace(paraText, '<p>', paraTag)}
            </c:when>
        <c:otherwise>
            <h4>Edit Paragraphs</h4>
        </c:otherwise>
    </c:choose>
</dess:cleanHTMLFragment>