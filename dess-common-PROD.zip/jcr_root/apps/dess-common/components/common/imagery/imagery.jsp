<%--
    
    Imagery component for Adaptive and Responsive images

    --%>
<%@include file="/apps/dess-common/components/global.jsp"%>

<%@taglib prefix="dess" uri="http://dess.co.in/desscommon"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>
<%@page session="false" %>

<dess:cleanHTMLFragment>
<c:if test="${properties.imagerytype eq 'adaptive'}">
    <picture>
        <!--[if IE 9]><video style="display: none;"><![endif]--> 
        <c:if test="${not empty properties.desktopimage}">
            <source srcset="${properties.desktopimage}" media="(min-width: 992px)">
        </c:if>
        <c:if test="${not empty properties.landscapetabletimage}">
            <source srcset="${properties.landscapetabletimage}" media="(min-width: 768px)">
        </c:if>
        <c:if test="${not empty properties.portraittabletimage}">
            <source srcset="${properties.portraittabletimage}" media="(min-width: 510px)">
        </c:if>
        <c:if test="${not empty properties.smartphoneimage}">
            <source srcset="${properties.smartphoneimage}" media="(min-width: 320px)">
        </c:if>
        <!--[if IE 9]></video><![endif]-->
        <c:if test="${not empty properties.smartphoneimage}">
            <img class="hidden-xs-ie8 ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="${properties.smartphoneimage}" srcset="${properties.smartphoneimage}" alt="${properties.imagealttext}">
        </c:if>
        <!--[if IE 8]>
		<c:if test="${not empty properties.desktopimage}">
            <img class="hidden-xs ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}"  src="${properties.desktopimage}" srcset="${properties.desktopimage}" alt="${properties.imagealttext}">
            </c:if>
            <c:if test="${not empty properties.smartphoneimage}">
            <img class="hidden-sm hidden-md hidden-lg ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="${properties.smartphoneimage}" srcset="${properties.smartphoneimage}"  alt="${properties.imagealttext}">
		</c:if>
		<![endif]-->
    </picture>
</c:if>

<c:if test="${properties.imagerytype eq 'responsive'}">
	<cq:include script="/apps/dess-common/components/imagery/responsiveImagery.jsp"/>
</c:if> 
</dess:cleanHTMLFragment>
