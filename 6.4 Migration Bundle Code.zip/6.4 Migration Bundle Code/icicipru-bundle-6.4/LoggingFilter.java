// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoggingFilter.java

package com.icicipru.core.impl.filters;

import java.io.IOException;
import javax.servlet.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.request.RequestPathInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingFilter
    implements Filter
{

    public LoggingFilter()
    {
        logger = LoggerFactory.getLogger(com/icicipru/core/impl/filters/LoggingFilter);
    }

    public void init(FilterConfig filterconfig)
        throws ServletException
    {
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException
    {
        SlingHttpServletRequest slingRequest = (SlingHttpServletRequest)request;
        logger.debug("request for {}, with selector {}", slingRequest.getRequestPathInfo().getResourcePath(), slingRequest.getRequestPathInfo().getSelectorString());
        chain.doFilter(request, response);
    }

    public void destroy()
    {
    }

    private Logger logger;
}
