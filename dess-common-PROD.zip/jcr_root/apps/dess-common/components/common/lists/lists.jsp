<%@include file="/apps/dess-common/components/global.jsp"%><%
%><%@page session="false" %>
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>

<c:if test="${wcmEditMode}">
<cq:includeClientLib categories="author.dess.common.components.lists"/>
</c:if>

<%
	List<Map<String, String>> valueMap = MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"multitermdesc");
	List<Map<String, String>> valueMapLinks = MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"multiiconlistlinks");
%>
<c:set var="definitionValues" value="<%=valueMap%>"/>
<c:set var="definitionValuesLinks" value="<%=valueMapLinks%>"/>
<c:set var="iconposition" value="${properties.iconposition}"/>
<c:if test="${properties.listactivateid}">
<c:set var="idlist" value="id=\"${properties.listid}\""/>
</c:if>

<c:set var="num" value=""/>
<c:forEach items="${definitionValuesLinks}" var="definitionValuesLink">
    <c:set var="numitem" value="${definitionValuesLink['numblock']}"/>
    <c:set var="num" value="${numitem} ${num}"/>
</c:forEach>
<c:choose>
	<c:when
    test="${properties.listtodisplay eq 'definitionlist'}">
			<dess:cleanHTMLFragment>	
        	<c:choose>                	
                    <c:when test="${properties.lifeStyleTag eq 'deflistdefault' && empty properties.cssoverride2}">
                        <c:choose>
                        <c:when test="${properties.appearwhenprinted eq 'true'}">
                        <dl ${idlist}>
                            <c:forEach items="${definitionValues}" var="definitionValue">
                                <dt>${definitionValue['term']}</dt>
                                <dd>${definitionValue['desc']}</dd>
                            </c:forEach>
                        </dl>
                        </c:when>
                        <c:otherwise>
                            <dl class="hidden-print" ${idlist}>
                            <c:forEach items="${definitionValues}" var="definitionValue">
                                <dt>${definitionValue['term']}</dt>
                                <dd>${definitionValue['desc']}</dd>
                            </c:forEach>
                        </dl>
                        </c:otherwise>
                        </c:choose>   
                    </c:when>

                    <c:when test="${properties.lifeStyleTag eq 'deflistdefault' && not empty properties.cssoverride2}">

                        <dl class="${properties.cssoverride2} ${properties.appearwhenprinted eq 'true' ? '' :'hidden-print'}" ${idlist}>
                            <c:forEach items="${definitionValues}" var="definitionValue">
                                <dt>${definitionValue['term']}</dt>
                                <dd>${definitionValue['desc']}</dd>
                            </c:forEach>
                        </dl>

                    </c:when>

                    <c:when test="${properties.lifeStyleTag eq 'horizontal'}">
                        <dl class="dl-horizontal ${empty properties.cssoverride2 ? '' :properties.cssoverride2} ${properties.appearwhenprinted eq 'true' ? '' :'hidden-print'}" ${idlist}>
                            <c:forEach items="${definitionValues}" var="definitionValue">
                                <dt>${definitionValue['term']}</dt>
                                <dd>${definitionValue['desc']}</dd>
                            </c:forEach>
                        </dl>   
                    </c:when>
                    <c:otherwise>
                    </c:otherwise>                        
            </c:choose>
            </dess:cleanHTMLFragment>    
        </c:when>
    	<c:when
   		 test="${properties.listtodisplay eq 'standardlist'}">
				<dess:cleanHTMLFragment>
            		 ${properties.listcontent}
             	</dess:cleanHTMLFragment>
        </c:when>
		<c:when
   		 test="${properties.listtodisplay eq 'linkslist'}">
             <dess:cleanHTMLFragment>
             <ul class=" ${properties.linksLifeStyleTag} ${empty properties.iconsize ? '' :properties.iconposition} ${properties.iconsize eq ('defaultsize' || '')? '':properties.iconsize} ${empty properties.cssoverride2 ? '' :properties.cssoverride2} ${properties.appearwhenprinted eq 'true' ? '' :'hidden-print'} ${fn:length(num) > fn:length(definitionValuesLinks) ? 'number-blocks' :''}" ${idlist}>
                <c:forEach items="${definitionValuesLinks}" var="definitionValuesLinks">
                <c:set var="cls" value="${empty properties.iconsize?'':'icon'} ${empty properties.iconsize?'':definitionValuesLinks['iconref']}"/>
                    <li>
                    <c:set var="startIndex_1" value="${fn:indexOf(definitionValuesLinks['desc'], '<a')}" />
                    <c:set var="startIndex_2" value="${fn:indexOf(definitionValuesLinks['desc'], '>')}" />
                    <c:set var="endIndex" value="${fn:indexOf(definitionValuesLinks['desc'], '</a>')}" />
                    <c:set var="definitionValuesLinks_desc" value="${fn:substring(definitionValuesLinks['desc'], startIndex_2+1, endIndex)}" />
                        <c:choose>
                            <c:when test="${not fn:contains(definitionValuesLinks['desc'], '<a')}">
                                <a href="#">
                            </c:when>
                        <c:otherwise>
							${fn:substring(definitionValuesLinks['desc'], startIndex_1, startIndex_2+1)}
                        </c:otherwise>
                        </c:choose>
						<c:if test="${not empty definitionValuesLinks['numblock']}">                            
							<span class="number-block">${definitionValuesLinks['numblock']}</span>
						</c:if>
                        <c:choose>
                            <c:when test="${empty iconposition}">
								${definitionValuesLinks_desc}
							</c:when>
						<c:otherwise>
                            <c:choose>
								<c:when test="${not empty iconposition && fn:contains(iconposition, 'left')}">									
                                    <c:if test="${not empty fn:replace(cls,' ','')}">
                            			<span class="${cls}"></span>
									</c:if>	
                                    ${definitionValuesLinks_desc}
                                </c:when>
                                <c:otherwise>
                                    ${definitionValuesLinks_desc}
                                    <c:if test="${not empty iconposition && fn:contains(iconposition, 'right') && not empty fn:replace(cls,' ','')}">
                            			<span class="${cls}"></span>
									</c:if>
                    			</c:otherwise>
							</c:choose>
					</c:otherwise>
					</c:choose>
                   	</a>
					</li> 
                </c:forEach>
   			 </ul>
             </dess:cleanHTMLFragment>    
        </c:when>
</c:choose>