<%--

    Links / Buttons component.

--%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>

<%if(WCMMode.fromRequest(request) == WCMMode.EDIT){%> 
<cq:includeClientLib categories="author.dess.common.components.linksbuttons"/>
<%}%> 

<c:if test="${not empty properties.visibleText}">

<c:if test="${properties.iconfixedposition}">
<c:choose>
    <c:when test="${properties.iconposition eq 'icon-left'}">
	<c:set var="iconfixedclass" value="${'icon-left-fixed'}"/>
    </c:when>
	<c:when test="${properties.iconposition eq 'icon-right'}">
    <c:set var="iconfixedclass" value="${'icon-right-fixed'}"/>
    </c:when>
</c:choose>
</c:if> 

<c:set var="classes" value="class=\"btn ${properties.styleClass} ${properties.buttonWidth} ${properties.buttonSize} ${not empty properties.iconref ? properties.iconsizelb : '' } ${not empty properties.iconref && !properties.iconfixedposition ? properties.iconposition : '' } ${not empty properties.iconref ? iconfixedclass : '' } ${properties.appearsOnPrint eq 'true' ? '' :'hidden-print'} ${empty properties.classoverridelb ? '' :properties.classoverridelb}\""/> 

<c:choose>
    <c:when test="${properties.appearsOnPrint ne 'true' || not empty properties.classoverridelb}">
        <c:choose>
            <c:when test="${properties.appearsOnPrint ne 'true' && empty properties.classoverridelb}">
                <c:set var="classesdf" value="class=\"hidden-print\""/>
            </c:when>
            <c:when test="${properties.appearsOnPrint eq 'true' && not empty properties.classoverridelb}">
                <c:set var="classesdf" value="class=\"${properties.classoverridelb}\""/>
            </c:when>
            <c:when test="${properties.appearsOnPrint ne 'true' && not empty properties.classoverridelb}">
                <c:set var="classesdf" value="class=\"hidden-print ${properties.classoverridelb}\""/>
            </c:when>
        </c:choose>
    </c:when>
    <c:otherwise>
        <c:set var="classesdf" value=""/>
    </c:otherwise>    
</c:choose>    

<c:set var="classAttributes" value="${properties.styleClass eq 'default' ? '' :'role=\"button\"'} ${properties.styleClass eq 'default' ? classesdf :classes}"/> 

<c:choose>
<c:when test="${properties.linkTargetOptions eq 'openurl'}">
    <c:set var="anchorAttributes" value="href=\"${properties.url}\" target=\"${properties.linktarget}\"" /> 
</c:when>
<c:when test="${properties.linkTargetOptions eq 'inpageanchor'}">
    <c:set var="anchorAttributes" value="href=\"${'#'}${properties.pageidselection}\""/> 
</c:when>
<c:when test="${properties.linkTargetOptions eq 'openamodal'}">
    <c:set var="anchorAttributes" value="href=\"${properties.modalurlref}\" data-toggle=\"modal\" data-target=\"${'#'}${properties.modalsize}\""/> 
</c:when>
</c:choose>

    <c:set var="title" value="title=\"${properties.buttontitle}\""/>
<dess:cleanHTMLFragment>
    <a ${anchorAttributes} ${classAttributes} ${empty properties.buttontitle ? '' : title} >
	<c:if test="${properties.iconposition eq ('icon-left') && not empty properties.iconref && properties.iconref ne 'None'}">
        <span class="icon ${properties.iconref}"></span>
    </c:if>
	${properties.visibleText}
    <c:if test="${not empty properties.screenReaderText}">    
		<span class="sr-only">${properties.screenReaderText}</span>
    </c:if>
     <c:if test="${properties.iconposition eq ('icon-right') && not empty properties.iconref && properties.iconref ne 'None'}">
        <span class="${properties.iconref}"></span>
    </c:if>
	</a>
</dess:cleanHTMLFragment> 

</c:if>