// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PopularListServiceImpl.java

package com.dess.cq.common.helper.impl;

import com.day.cq.statistics.StatisticsService;
import com.day.cq.wcm.api.*;
import com.day.cq.wcm.core.stats.PageViewReport;
import com.dess.cq.common.helper.PopularListService;
import com.dess.cq.common.search.models.*;
import java.io.Serializable;
import java.util.*;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PopularListServiceImpl
    implements PopularListService
{
    private class SortByImpression
        implements Comparator, Serializable
    {

        public int compare(CommonSearchResult leftObject, CommonSearchResult rightObject)
        {
            int i = 0;
            if(leftObject.getPageViews() < rightObject.getPageViews())
                i = 1;
            else
            if(leftObject.getPageViews() > rightObject.getPageViews())
                i = -1;
            else
                i = 0;
            return i;
        }

        public volatile int compare(Object obj, Object obj1)
        {
            return compare((CommonSearchResult)obj, (CommonSearchResult)obj1);
        }

        private static final long serialVersionUID = 1L;
        final PopularListServiceImpl this$0;

        private SortByImpression()
        {
            this$0 = PopularListServiceImpl.this;
            super();
        }

    }


    public PopularListServiceImpl()
    {
    }

    public CommonSearchResultWrapper getMostPopularResult(CommonSearchRequest commonSearchRequest, Page mostpopularPage)
        throws RepositoryException
    {
        return getImpressionObject(commonSearchRequest, mostpopularPage);
    }

    private CommonSearchResultWrapper getImpressionObject(CommonSearchRequest commonSearchRequest, Page mostpopularPage)
        throws RepositoryException
    {
        String limit = commonSearchRequest.getLimit();
        List pageList = calcPageViews(commonSearchRequest, mostpopularPage);
        Collections.sort(pageList, new SortByImpression());
        int resultLimit;
        if(pageList.size() >= Integer.parseInt(limit))
            resultLimit = Integer.parseInt(limit);
        else
            resultLimit = pageList.size();
        List sortedImpression = pageList.subList(0, resultLimit);
        CommonSearchResultWrapper wrapper = new CommonSearchResultWrapper();
        Pagination pagination = new Pagination();
        wrapper.setPaginationObject(pagination);
        wrapper.setResults(sortedImpression);
        return wrapper;
    }

    private List calcPageViews(CommonSearchRequest commonSearchRequest, Page mostpopularPage)
        throws RepositoryException
    {
        HttpServletRequest request = commonSearchRequest.getRequest();
        String tagSearch[] = commonSearchRequest.getTagSearchArray();
        List mostPopularPageList = new ArrayList();
        for(Iterator rootPage = mostpopularPage.listChildren(new PageFilter(request)); rootPage.hasNext();)
        {
            Page childPage = (Page)rootPage.next();
            if(tagSearch != null && tagSearch.length > 0)
            {
                boolean isTagged = isTaggedPage(childPage, tagSearch);
                if(isTagged)
                {
                    mostPopularPageList.add(calcChildPageViews(request, childPage));
                    iterateTillEnd(childPage, mostPopularPageList, commonSearchRequest);
                } else
                {
                    iterateTillEnd(childPage, mostPopularPageList, commonSearchRequest);
                }
            } else
            {
                mostPopularPageList.add(calcChildPageViews(request, childPage));
                iterateTillEnd(childPage, mostPopularPageList, commonSearchRequest);
            }
        }

        return mostPopularPageList;
    }

    private void iterateTillEnd(Page mostpopularPage, List mostPopularPageList, CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        HttpServletRequest request = commonSearchRequest.getRequest();
        String tagSearch[] = commonSearchRequest.getTagSearchArray();
        for(Iterator children = mostpopularPage.listChildren(new PageFilter(request)); children.hasNext();)
        {
            Page nextChild = (Page)children.next();
            if(tagSearch != null && tagSearch.length > 0)
            {
                boolean isTagged = isTaggedPage(nextChild, tagSearch);
                if(isTagged)
                {
                    iterateTillEnd(nextChild, mostPopularPageList, commonSearchRequest);
                    mostPopularPageList.add(calcChildPageViews(request, nextChild));
                } else
                {
                    iterateTillEnd(nextChild, mostPopularPageList, commonSearchRequest);
                }
            } else
            {
                iterateTillEnd(nextChild, mostPopularPageList, commonSearchRequest);
                mostPopularPageList.add(calcChildPageViews(request, nextChild));
            }
        }

    }

    private CommonSearchResult calcChildPageViews(HttpServletRequest request, Page mostpopularPage)
        throws RepositoryException
    {
        CommonSearchResult searchResult = new CommonSearchResult();
        LOGGER.info("Child page Title :: {}", mostpopularPage.getTitle());
        String pageDescription = "";
        if(mostpopularPage.getProperties().get("jcr:description") != null)
            pageDescription = (String)mostpopularPage.getProperties().get("jcr:description");
        searchResult.setResultPath((new StringBuilder()).append(mostpopularPage.getPath()).append(".html").toString());
        searchResult.setResultTitle(mostpopularPage.getTitle());
        searchResult.setResultDescription(pageDescription);
        int totalPageViews = 0;
        PageViewReport report = new PageViewReport((new StringBuilder()).append(statService.getPath()).append("/pages").toString(), mostpopularPage, WCMMode.EDIT);
        report.setPeriod(30);
        for(Iterator stats = statService.runReport(report); stats.hasNext();)
        {
            Object res[] = (Object[])(Object[])stats.next();
            totalPageViews += Integer.parseInt(res[1].toString());
        }

        searchResult.setPageViews(totalPageViews);
        return searchResult;
    }

    public boolean isTaggedPage(Page currentPage, String tagSearch[])
    {
        boolean isTagged = false;
        if(tagSearch != null && tagSearch.length > 0 && currentPage != null && currentPage.getProperties("cq:tags") != null)
        {
            String currentTags[] = (String[])(String[])currentPage.getProperties().get("cq:tags", new String[0]);
            if(currentTags != null && currentTags.length > 0)
            {
                boolean breakLoop = false;
                do
                {
                    if(breakLoop)
                        break;
                    for(int i = 0; i < tagSearch.length; i++)
                        if(Arrays.asList(currentTags).contains(tagSearch[i]))
                        {
                            isTagged = true;
                            breakLoop = true;
                        }

                    if(!breakLoop)
                        breakLoop = true;
                } while(true);
            }
        }
        return isTagged;
    }

    protected void bindStatService(StatisticsService paramStatisticsService)
    {
        statService = paramStatisticsService;
    }

    protected void unbindStatService(StatisticsService paramStatisticsService)
    {
        if(statService == paramStatisticsService)
            statService = null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/helper/impl/PopularListServiceImpl);
    private static final int PERIOD = 30;
    private transient StatisticsService statService;

}
