// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GenericLinkItemUseClass.java

package com.icicipru.sightly.use;

import com.adobe.cq.sightly.WCMUsePojo;
import com.icicipru.sightly.bean.LinkBean;
import java.util.ArrayList;
import java.util.List;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericLinkItemUseClass extends WCMUsePojo
{

    public GenericLinkItemUseClass()
    {
        links = new ArrayList();
    }

    public List getLinks()
    {
        return links;
    }

    public void setLinks(List links)
    {
        this.links = links;
    }

    public String[] getStringArray()
    {
        return stringArray;
    }

    public void setStringArray(String stringArray[])
    {
        this.stringArray = stringArray;
    }

    public void activate()
        throws Exception
    {
        LOGGER.info("GenericLinkItemUseClass STARTS");
        Object runtimeObj = get("runtimeJsonStringArray", java/lang/Object);
        if(runtimeObj != null)
        {
            LOGGER.info((new StringBuilder()).append("GenericLinkItemUseClass runtime array object type: ").append(runtimeObj.getClass()).toString());
            if(runtimeObj.getClass() == java/lang/String)
                stringArray = (new String[] {
                    (String)get("runtimeJsonStringArray", java/lang/String)
                });
            else
                stringArray = (String[])(String[])runtimeObj;
        }
        LOGGER.info((new StringBuilder()).append("GenericLinkItemUseClass runtime array from sightly: ").append(stringArray).toString());
        if(getStringArray().length > 0)
        {
            LOGGER.debug((new StringBuilder()).append("stringArray length found to be:").append(getStringArray().length).toString());
            try
            {
                String as[] = getStringArray();
                int i = as.length;
                for(int j = 0; j < i; j++)
                {
                    String Obj = as[j];
                    JSONObject jsonObject = new JSONObject(Obj);
                    LinkBean link = new LinkBean();
                    link.setTitle(jsonObject.has("text") ? jsonObject.getString("text") : "");
                    link.setId(jsonObject.has("id") ? jsonObject.getString("id") : "");
                    link.setLink(jsonObject.has("url") ? jsonObject.getString("url") : "");
                    link.setNrOfCols(jsonObject.has("cols") ? jsonObject.getString("cols") : "");
                    link.setCssClass(jsonObject.has("cssclass") ? jsonObject.getString("cssclass") : "");
                    link.setActive(jsonObject.has("active") ? jsonObject.getString("active") : "");
                    link.setForDesktop(jsonObject.has("desktop") ? jsonObject.getString("desktop") : "");
                    link.setForMobile(jsonObject.has("mobile") ? jsonObject.getString("mobile") : "");
                    links.add(link);
                }

            }
            catch(JSONException je)
            {
                LOGGER.error("JSONException:", je);
            }
            catch(Exception e)
            {
                LOGGER.error("Exception:", e);
            }
        } else
        {
            LOGGER.debug("stringArray length found to be empty");
        }
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/sightly/use/GenericLinkItemUseClass);
    private String stringArray[];
    private List links;

}
