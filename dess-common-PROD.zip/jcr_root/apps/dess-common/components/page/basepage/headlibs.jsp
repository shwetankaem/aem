<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@ page import="java.util.Date,
				   java.text.SimpleDateFormat,
				   com.day.cq.commons.Doctype,
                   org.apache.commons.lang3.StringEscapeUtils,
                   org.apache.commons.lang3.StringUtils" %>
                   
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>                       
<%@page import="com.day.cq.tagging.Tag"%>
<%@page import="com.day.cq.tagging.TagManager"%>

<%
response.addHeader("X-UA-Compatible", "IE=edge");
List<Map<String, String>> customcssMap = MultiFieldPanelFunctions.getInheritedMultiFieldPanelValues(pageProperties.getInherited("multicustomcss",String[].class));
%>
<c:set var="customcssvalues" value="<%=customcssMap%>"/>
                   
<%
String xs = Doctype.isXHTML(request) ? "/" : "";
%>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<%
String iconsPath = currentDesign.getPath() + "/favicon";

if(!properties.get("cq:lastModified", "").equals("")) {
	SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy HH:mm:ss z");
	String date = sdf.format(properties.get("cq:lastModified", Date.class) );
    %><meta http-equiv="Last-Modified" content="<%= StringEscapeUtils.escapeHtml4(date) %>"<%=xs%>><%
}

if(!properties.get("cq:lastModifiedBy", "").equals("")) {
    %><meta name="author" content="<%= StringEscapeUtils.escapeHtml4(properties.get("cq:lastModifiedBy", "")) %>"<%=xs%>><%
}

if(!properties.get("jcr:title", "").equals("")) {
    %>
<title><%= StringEscapeUtils.escapeHtml4(properties.get("jcr:title", "")) %></title>
<meta name="title" content="<%= StringEscapeUtils.escapeHtml4(properties.get("jcr:title", "")) %>"<%=xs%>><%
}

if(!properties.get("subtitle", "").equals("")) {
    %><meta name="subtitle" content="<%= StringEscapeUtils.escapeHtml4(properties.get("subtitle", "")) %>"<%=xs%>><%
}

if(properties.get("cq:tags", new String[0]).length > 0) {
    String tagArray[] = properties.get("cq:tags", new String[0]);
    StringBuilder keywords = new StringBuilder();
    TagManager tagManger = resourceResolver.adaptTo(TagManager.class);
    for(int i=0;i<tagArray.length;i++){
	    Tag tag = tagManger.resolve(tagArray[i]);
		keywords.append(tag.getTitle());
        if(i < tagArray.length-1){
			keywords.append(",");
        }
    }
	%><meta name="keywords" content="<%= StringEscapeUtils.escapeHtml4(keywords.toString()) %>"<%=xs%>><%
}

if(!properties.get("jcr:description", "").equals("")) {
    %><meta name="description" content="<%= StringEscapeUtils.escapeHtml4(properties.get("jcr:description", "")) %>"<%=xs%>><%
}
%>

<link rel="shortcut icon" href="<%=iconsPath%>/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="<%=iconsPath%>/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="114x114" href="<%=iconsPath%>/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="72x72" href="<%=iconsPath%>/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="144x144" href="<%=iconsPath%>/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="60x60" href="<%=iconsPath%>/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="120x120" href="<%=iconsPath%>/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="76x76" href="<%=iconsPath%>/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="152x152" href="<%=iconsPath%>/apple-touch-icon-152x152.png">
<link rel="icon" type="image/png" href="<%=iconsPath%>/favicon-196x196.png" sizes="196x196">
<link rel="icon" type="image/png" href="<%=iconsPath%>/favicon-160x160.png" sizes="160x160">
<link rel="icon" type="image/png" href="<%=iconsPath%>/favicon-96x96.png" sizes="96x96">
<link rel="icon" type="image/png" href="<%=iconsPath%>/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="<%=iconsPath%>/favicon-16x16.png" sizes="16x16">
<meta name="msapplication-TileColor" content="#fff">
<meta name="msapplication-TileImage" content="<%=iconsPath%>/mstile-144x144.png">
<meta name="msapplication-square70x70logo" content="<%=iconsPath%>/mstile-70x70.png">
<meta name="msapplication-square144x144logo" content="<%=iconsPath%>/mstile-144x144.png">
<meta name="msapplication-square150x150logo" content="<%=iconsPath%>/mstile-150x150.png">
<meta name="msapplication-square310x310logo" content="<%=iconsPath%>/mstile-310x310.png">
<meta name="msapplication-wide310x150logo" content="<%=iconsPath%>/mstile-310x150.png">

<cq:includeClientLib css="open.framework.bootstrap"/>
<cq:includeClientLib css="dess.common.main"/>

<cq:include script="/libs/wcm/core/components/init/init.jsp" />

<c:forEach items="${customcssvalues}" var="customcssvalues">
    <c:choose>
        <c:when test="${empty properties.multicustomcss && fn:length(customcssvalues['inheritcss']) > 2  }">
			<c:if test="${not empty customcssvalues['csspath']}">
            	<link type="text/css" rel="stylesheet" href="${customcssvalues['csspath']}">
           	</c:if>
        </c:when>
        <c:when test="${not empty properties.multicustomcss}">
			<c:if test="${not empty customcssvalues['csspath']}">
        		<link type="text/css" rel="stylesheet" href="${customcssvalues['csspath']}">
            </c:if>    
        </c:when>
    </c:choose>
</c:forEach>
<cq:includeClientLib js="open.framework.modernizr"/>
<!--[if lt IE 9]>
      <cq:includeClientLib js="open.framework.html5JSPlugin"/>
      <cq:includeClientLib js="open.framework.respond.min"/>
<![endif]-->