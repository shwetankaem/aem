<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page import="com.day.cq.wcm.foundation.Placeholder"%>
<%@page
	import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions,java.util.Map,java.util.List"%>
<%@page session="false"%>

<%
	String listType = properties.get("listType", "");
	List<Map<String, String>> searchDropDown = MultiFieldPanelFunctions
			.getMultiFieldPanelValues(resource, "searchDropDown");
%>
<c:if test="${wcmEditMode}">
	<cq:includeClientLib categories="author.dess.common.widget.multifieldpanel" />
</c:if>

<c:set var="definitionValues" value="<%=searchDropDown%>" />

<cq:includeClientLib categories="handlebars" />
<div id="searchHeader"></div>

<div
	class="configured-list ${properties.appearsOnPrint?'hidden-print':''}">

	<c:if test="${properties.listType == 'relatedList'}">
		<c:if test="${properties.relatedListTitle != ''}">
		                           <${properties.heirarchy} class="${properties.heirarchy}">
		                               ${properties.relatedListTitle}
		                           </${properties.heirarchy}>
		                       </c:if>
	</c:if>
	<c:if test="${properties.listType == 'latestList'}">
		<c:if test="${properties.searchable}">
			<div class="search-bar">


				<form id="jsSearchBarForConfigList"
					action="<%=currentPage.getPath()%>.html"
					class="form-inline form-search" role="search">
					<fieldset>


						<legend class="sr-only"><%=xssAPI.encodeForHTML(properties.get("legendName",
							""))%></legend>

						<div class="form-group">
							<div class="row">
								<div class="col-xs-12 search-filter">

									<p id="error-div-config-list" class="hidden" aria-hidden="true">
										<span class="icon icon-alert"></span>You did not enter a
										search term
									</p>

									<div class="search-input">
										<label class="sr-only control-label" for="searchInput">Text
											Input for search</label> <input id="searchInputForConfigList"
											value="<%=xssAPI.encodeForHTML(request
							.getParameter("searchInput") != null ? request
							.getParameter("searchInput") : "")%>"
											class="form-control" name="searchInput" type="search"
											placeholder="<%=xssAPI.encodeForHTML(properties.get(
							"placeholderText", ""))%>"
											aria-required="true" aria-invalid="false">
									</div>

									<div class="search-select">
										<c:if test="${fn:length(definitionValues) > 0}">

											<label class="sr-only control-label" for="selectArea">Select
												area to search in</label>

											<select id="selectAreaForConfigList" name="selectArea"
												class="form-control">
												<c:forEach items="${definitionValues}" var="definitionValue">
													<option value="${definitionValue['searchPath']}"
														<c:if test="${param.selectArea eq definitionValue['searchPath']}">
                                                                            selected
                                                                        </c:if>>${definitionValue['labelForDropDown']}</option>
												</c:forEach>
											</select>
										</c:if>

										<button id="searchButtonForConfigList" type="button"
											class="btn btn-primary btn-block icon-right-fixed icon-lg">
											Search<span class="icon icon-search"></span>
										</button>

									</div>

								</div>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</c:if>
	</c:if>
	<%@include file="configured-list-result.jsp"%>
</div>