// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   NestedTitleAndLink.java

package com.icicipru.sightly.bean;


public class NestedTitleAndLink
{

    public NestedTitleAndLink()
    {
    }

    private String title;
    private String link;
    private String innerLinks[];
}
