<%@page language="java" contentType="application/json; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@taglib prefix="dess" uri="http://dess.co.in/desscommon"%>
${dess:childTagsAsJSON(pageContext,param.tagID)}