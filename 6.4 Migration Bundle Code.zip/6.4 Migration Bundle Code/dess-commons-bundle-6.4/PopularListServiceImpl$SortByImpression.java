// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PopularListServiceImpl.java

package com.dess.cq.common.helper.impl;

import com.dess.cq.common.search.models.CommonSearchResult;
import java.io.Serializable;
import java.util.Comparator;

// Referenced classes of package com.dess.cq.common.helper.impl:
//            PopularListServiceImpl

private class PopularListServiceImpl$SortByImpression
    implements Comparator, Serializable
{

    public int compare(CommonSearchResult leftObject, CommonSearchResult rightObject)
    {
        int i = 0;
        if(leftObject.getPageViews() < rightObject.getPageViews())
            i = 1;
        else
        if(leftObject.getPageViews() > rightObject.getPageViews())
            i = -1;
        else
            i = 0;
        return i;
    }

    public volatile int compare(Object obj, Object obj1)
    {
        return compare((CommonSearchResult)obj, (CommonSearchResult)obj1);
    }

    private static final long serialVersionUID = 1L;
    final PopularListServiceImpl this$0;

    private PopularListServiceImpl$SortByImpression()
    {
        this$0 = PopularListServiceImpl.this;
        super();
    }

}
