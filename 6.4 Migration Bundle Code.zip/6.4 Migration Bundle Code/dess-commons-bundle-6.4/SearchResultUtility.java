// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SearchResultUtility.java

package com.dess.cq.common.utilities;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import java.util.Iterator;
import java.util.List;
import javax.jcr.*;
import org.apache.sling.commons.json.JSONObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SearchResultUtility
{

    public SearchResultUtility()
    {
    }

    public static String processSearchHit(SearchResult results, String currentPagePath, String propertyName, Session session)
    {
        String propertyValue = "";
        long totalMatches = results.getTotalMatches();
        if(totalMatches > 0L)
        {
            Iterator iterator = results.getHits().iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                Hit hit = (Hit)iterator.next();
                try
                {
                    Node resultNode = session.getNode(hit.getPath());
                    if(resultNode != null && resultNode.hasProperty(propertyName))
                        propertyValue = resultNode.getProperty(propertyName).getValue().getString();
                }
                catch(PathNotFoundException e)
                {
                    LOGGER.error("PathNotFoundException :: {}", e.getMessage());
                }
                catch(RepositoryException e)
                {
                    LOGGER.error("RepositoryException :: {}", e.getMessage());
                }
            } while(true);
        }
        return propertyValue;
    }

    public static JSONObject convertToJSON(Object object)
    {
        String jsonHitAsString = "";
        JSONObject jsonObject = new JSONObject();
        try
        {
            ObjectMapper mapper = new ObjectMapper();
            ObjectWriter ow = (new ObjectMapper()).writer().withDefaultPrettyPrinter();
            jsonHitAsString = mapper.writeValueAsString(object);
            jsonObject = new JSONObject(jsonHitAsString);
        }
        catch(Exception e)
        {
            LOGGER.error("Exception in Search Utililty method convertToJSON {}", e.getMessage());
        }
        return jsonObject;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/utilities/SearchResultUtility);

}
