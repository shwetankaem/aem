<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page import="com.dess.cq.common.helper.JcrQueryBuilder" %>
<%
Session session = resource.getResourceResolver().adaptTo(Session.class);
JcrQueryBuilder builder = sling.getService(JcrQueryBuilder.class);
long modalCountOnPage = builder.getCurrentPageModals(currentPage.getPath(), session);
%>
<c:set var="modalCountOnPage" value="<%=modalCountOnPage%>"/>
<cq:includeClientLib js="open.framework.jquery" />
<cq:includeClientLib js="open.framework.bootstrap"/>
<cq:includeClientLib js="dess.common.main"/>

<c:if test="${modalCountOnPage gt 0}">
      <%-- Default Modal frame standard --%>
        <div class="modal fade" id="defaultModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
              <div class="modal-content"></div>
          </div>
        </div>
<%-- Default Modal frame standard --%>
<%-- Modal frame Small --%>
        <div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content"></div>
          </div>
        </div>
<%-- Modal frame Small --%>
<%-- Modal frame Large --%>
        <div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content"></div>
          </div>
        </div>
<%-- Modal frame Large --%>
</c:if>