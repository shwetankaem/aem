<%--

  Notifications component.

--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%>
<%
%><%@page session="false" %>

<c:if test="${properties.activateid}">
<c:set var="idnotification" value="id=\"${properties.notificationid}\""/>
</c:if>

<c:choose>
<c:when test="${fn:length(properties.notificationtype) > 0}">
<%if(WCMMode.fromRequest(request) == WCMMode.EDIT){%>    
	<c:set var="dataComponent" value=""/>
<%} else {%>  
	<c:set var="dataComponent" value="data-component=\"notification\""/>                       
<%}%>    
<div class="alert ${properties.notificationtype} 
					${empty properties.classappend ? '' :properties.classappend} 
					${properties.dissmissable eq 'no' ? '' :properties.dissmissable}" 
   					role="alert" ${idnotification} ${dataComponent}>
                   <cq:include path="notificationstext" resourceType="foundation/components/parsys" />     
            <c:if test="${properties.dissmissable != 'no'}">
				<button title="Close this statement" type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close this statement</span>
                </button>
<%--
                <button class="alert-close-btn pull-right btn btn-link btn-never-block icon-xl" title="Close this statement" type="button" data-dismiss="alert">
     					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
      					<span class="sr-only">Close this statement</span>
      				</button>--%>
			</c:if>
</div>
</c:when>
<c:otherwise>
    <h4>Edit Notifications</h4>
</c:otherwise>
</c:choose>
