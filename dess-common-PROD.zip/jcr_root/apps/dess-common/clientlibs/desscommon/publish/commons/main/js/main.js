/**
*
* Main js used for triggering all usefull methods
*
**/


// Replace svg's if browser does not support svg
$.fn.svgtopng = function() {
	if (!Modernizr.svg) {
    //$(".brand img").attr("src", "./img/retire-ready-logo.png");
    // $(".aegon img").attr("src", "./img/aegon-logo.png");
     
    jQuery('img').each(function(index,element){
            // if there's a .svg in the source, I'll assume it's at the end
            // (of course, more complex test could be made) ...
            if (element.src.indexOf('.svg') != -1) {
                // ...and replace it with a png version
                element.src = element.src.replace('.svg','.png'); 
            }
        }); 
	}
};

// Ajax for accordian
$.fn.ajaxaccordian = function () {
    $(document).on("click", ".js-ajax-expandable", function(event) {
        var el = $(this);
        var prContainer = el.parent();
        var datapr = $(this).find('a').attr("data-parent");
        if(datapr) {
            $('.panel .js-ajax-expandable').each(function(i,obj){
                if($(obj).find('a').hasClass('collapsed')){
                    $(obj).find(".icon-plus").show();  
                }
            });
        }
        var url = $(this).attr("data-ref");
        var href = $(this).find("a").attr("href");
        if(typeof href === "undefined") {
            var href = $(this).attr("href");
        }
        if ($(this).find("a").hasClass("collapsed")) {
            el.find("a .icon-plus").show();
        }
        if (el.parent().hasClass("read-more")) {
            el.parent().hide();
        }
        if(url) {
            el.find("a .icon-plus").hide();
            el.find("a .icon-loading").removeClass("hidden");
            $.ajax({
                url: url,
                type: "get",
                dataType: "html",
                success: function (data) { 
                    $(el).attr("data-ref","");
                    el.find("a .icon-loading").addClass("hidden");
                    $(href).html(data);
                }
            });
        }

   });
    $(document).on("click", ".panel-heading a", function(event) {
        var datapr = $(this).attr("data-parent");
        if(datapr) {
            $('.panel .js-ajax-expandable').each(function(i,obj){
                if($(obj).find('a').hasClass('collapsed')){
                    $(obj).find(".icon-plus").show();  
                }
            });
        }
    });
};

// Scroll to has plugin on page load if the url has any hash
$.fn.scrollToHash = function () {
    var anchor = window.location.hash;
    if(anchor) {
        $.fn.scrollToElement(anchor,300, 0);
        var prContainer = $(anchor).parent();
        $(prContainer).find(".panel-heading").trigger("click");
        $(prContainer).find(".panel-heading a").removeClass("collapsed");
        $(anchor).collapse('toggle');
    }  
};

// Adding scope to table for accessibility
$.fn.tableScope = function (){
    $('.table').each(function(i, obj) {
        var el = $(obj).find("tr:first th:first");
        var ell = $(obj).find("tr:eq(1) th:first");
        var vHead = $(obj).find("tbody tr:first th");
        var hHead = $(obj).find("tbody tr");
    
        if($(el).next().is('th')) {
            $(vHead).attr("scope","col");
            $(hHead).each(function(i, j) {
                if (i > 0) {
                    $(j).find("th").attr("scope","row");
                }
            });
        }
        else if($(el).next().is('td')) {
            $(hHead).each(function(i, ob) {
                $(ob).find("th").attr("scope","row");
            });
        }
    });
};


$.fn.configResults = function() {
    var resultsSource = $("#config-results-template").html();
    var resultsTemplate = Handlebars.compile(resultsSource);

    $("#configResults").on("click", ".pager li.next a", function(e) {
        e.preventDefault();
        $("#jsLoadingSpinner").removeClass("hidden");
        var nextAjaxURL = $(this).attr('href');
        $.get(nextAjaxURL, function(data) {
            $("#jsLoadingSpinner").addClass("hidden");
            $("#configResults").html(resultsTemplate(data));
        }, "json");

    });

    $("#configResults").on("click", ".pager li.previous a", function(e) {
        e.preventDefault();
        $("#jsLoadingSpinner").removeClass("hidden");
        var previousAjaxUrl = $(this).attr('href');
        $.get(previousAjaxUrl, function(data) {
            $("#jsLoadingSpinner").addClass("hidden");
            $("#configResults").html(resultsTemplate(data));
        }, "json");
    });
};
// clear remote modal
$.fn.removeModalCache = function(){
    $('body').on('hidden.bs.modal', '.modal', function () {
        $(this).removeData('bs.modal');
    });
};

$.fn.readmore = function() {
    $(document).on("click",".js-read-more", function (e) {
        $(this).hide();
        false;
    });
};
// Init all methods based on if the dom element exist
$( document ).ready(function() {
	$.fn.svgtopng();
    $('#navTopMenuButton').exists(function() {
        $.fn.navToggle();
    });
    $('.js-ajax-expandable').exists(function() {
        $.fn.ajaxaccordian();
    });
    $('#configResults').exists(function() {
        $.fn.configResults();
    });
    $.fn.scrollToHash();
 	$('.equal').matchHeight();
    $(".table").exists(function() {
        $.fn.tableScope();
    });
    $(".js-read-more").exists(function() {
        $.fn.readmore();
    });

    $.fn.removeModalCache();



    // Article back to Results Functionality JS
if(document.referrer.indexOf("?searchInput")>-1) {
		$(".backtosearch").show();
}else{
		$(".backtosearch").hide();
}

$(".backtosearch").on("click",function(e) {
	  e.preventDefault();
      window.location.href = document.referrer;
});

});
