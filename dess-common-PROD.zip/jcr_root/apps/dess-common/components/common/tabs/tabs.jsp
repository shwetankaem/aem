<%--

    Tabs component.

--%>

<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false"%>
<%@page trimDirectiveWhitespaces="true" %>    
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>

<%if(WCMMode.fromRequest(request) == WCMMode.EDIT){%> 
	<cq:includeClientLib categories="author.dess.common.widget.multifieldpanel"/>
	<cq:includeClientLib categories="author.dess.common.limitmultifields"/>
<%}%>

<%
	List<Map<String, String>> valueMap = MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"tabsitems");
%>

<c:set var="tabValues" value="<%=valueMap%>"/>
<c:set var="allclsovrd" value=""/>

<c:forEach items="${tabValues}" var="tabValue">
	<c:set var="clsovrd" value="${tabValue['classoverrideitm']}"/>
    <c:set var="allclsovrd" value="${clsovrd} ${allclsovrd}"/>
</c:forEach>

<c:choose>
    <c:when test="${fn:length(properties.styleClass) > 0}">
        <dess:cleanHTMLFragment>
        <div class="${properties.classoverridetab} ${properties.appearsOnPrint eq 'true' ? '' :'hidden-print'}" role="tabpanel">
            <ul class="nav ${properties.styleClass} ${properties.transformtodropdown} ${allclsovrd}" role="tablist">
                <c:forEach items="${tabValues}" var="tabValue">
                    <li role="presentation" class="${tabValue['activeonload'] eq 'true' ? 'active' : ''}">
                        <a href="#${tabValue['tabsitemid']}" aria-controls="tab####" role="tab" data-toggle="tab">
                            ${tabValue['visibleText']}
							<c:if test="${not empty tabValue['screenReaderText']}">
                                <span class="sr-only">
                                    ${tabValue['screenReaderText']}
                                </span>
                            </c:if>    
                        </a>
                    </li>
                </c:forEach>    
            </ul>
            <div class="tab-content">
                <c:forEach items="${tabValues}" var="tabValue">
                    <div role="tabpanel" class="tab-pane ${tabValue['activeonload'] eq 'true' ?'active': ''}" id="${tabValue['tabsitemid']}">
                        <cq:include path="tabcontent-${tabValue['tabsitemid']}" resourceType="foundation/components/parsys" />
                    </div>	
                </c:forEach> 
            </div>
        </div>
		</dess:cleanHTMLFragment>
	</c:when> 
	<c:otherwise>
            <h4>Edit Tabs</h4>
    </c:otherwise>	        
</c:choose>