<%@page import="com.dess.cq.common.utilities.SearchResultUtility"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page import="com.dess.cq.common.helper.ConfiguredListService,com.dess.cq.common.search.models.CommonSearchResultWrapper,com.dess.cq.common.search.models.CommonSearchRequest,java.util.*"%>
<%
	String jsonToString = "";
	String connectTo = properties.get("connectTo", currentPage.getPath());
	ConfiguredListService configListService = sling.getService(ConfiguredListService.class);
	Page parentPage = currentPage.getAbsoluteParent(1);
	String [] tagArray = properties.get("tagSearch", String[].class);
	String searchText = "";
    if (listType.equalsIgnoreCase("latestList")){
        if (request.getParameter("selectArea") != null && !request.getParameter("selectArea").equalsIgnoreCase("")) {
            connectTo = request.getParameter("selectArea");
        } 
    }
    if (listType.equalsIgnoreCase("relatedList")){
    	connectTo = currentPage.getPath();
    }
    
    CommonSearchRequest commonSearchRequest = new CommonSearchRequest();
    commonSearchRequest.setSearchPath(connectTo);
    commonSearchRequest.setOffset("0");
    commonSearchRequest.setLimit(properties.get("listCount", "10"));
    commonSearchRequest.setListType(properties.get("listType", ""));
    commonSearchRequest.setTagSearchArray(tagArray);
    if(request.getParameter("searchInput")!=null && !request.getParameter("searchInput").equalsIgnoreCase("")) {
		searchText = request.getParameter("searchInput");
	}
    commonSearchRequest.setSearchInput(searchText);
    commonSearchRequest.setRequest(slingRequest);
    

    CommonSearchResultWrapper commonSearchResultObject = configListService.getConfiguredListResult(commonSearchRequest);
    
    if(commonSearchResultObject!=null && commonSearchResultObject.getResults()!=null  && commonSearchResultObject.getResults().size() > 0) {
    
    	jsonToString = SearchResultUtility.convertToJSON(commonSearchResultObject).toString();
%>


<script id="config-results-template" type="text/x-handlebars-template">

        <div id="jsLoadingSpinner" class="ajax-loading hidden" aria-hidden="true" role="alert">Loading results</div>

<ul id="configList0001" class=" list-items ${properties.showIcon eq 'true'?'':'list-items-no-icon'}" aria-live="polite">
             {{#each results}}
              <li>
              <a href="{{resultPath}}" class="${properties.showIcon eq 'true'?'{{resultClass}}':''}" target="{{target}}">
                  <span class="${properties.smallTitle?'list-item-sm':'list-item-title'}">{{resultTitle}}</span>
				 {{#if isAsset}}
				  <span class="sr-only">(Opens in a new window)</span>
				  <span class="sr-only"> - </span>
				  <span class="list-item-info">{{docType}} ({{assetSize}}{{unit}})</span>
				 {{/if}}
                 <c:if test="${properties.showDecsription}">
                     {{#if resultDescription}}
                      <span class="list-item-short-desc">{{resultDescription}}</span>
                      {{/if}}
				</c:if>
                </a>
              </li>
              {{/each}}
            </ul>

    <c:if test="${properties.listType == 'latestList'}">
        <c:if test="${properties.pagination}">
            {{#with paginationObject}}

            <ul class="pager">
                {{#if disablePrevButton}}
                 <li class="previous disabled"><a href="#"><span class="icon icon-arrow-left"></span>Prev<span class="sr-only">ious set part of results</span></a></li>
                 {{else}}
     <li class="previous"><a href="{{previousPageAjaxUrl}}"><span class="icon icon-arrow-left"></span>Prev<span class="sr-only">ious set part of results</span></a></li>
     {{/if}}
     <li class="count">{{currentPageIndex}} of {{totalPages}}</li>
     {{#if disableNextButton}}
     <li class="next disabled"><a href="#">Next<span class="sr-only"> set part of results</span><span class="icon icon-arrow-right"></span></a></li>
     {{else}}
      <li class="next"><a href="{{nextPageAjaxUrl}}">Next<span class="sr-only"> set part of results</span><span class="icon icon-arrow-right"></span></a></li>
      {{/if}}
</ul>
{{/with}}
</c:if>
	</c:if>

</script>

<div id="configResults"></div><script>
	var resultArrayJSON = <%=jsonToString%>;

</script>
<% }else { %>

<div id="jsResultsHeader"class"col-sm-12col-md-12col-lg-12">
	<c:if test="${wcmEditMode}">
	<p aria-live="polite" class="h3">
	
			<c:if test="${not empty properties.noResultFound}">    
			${properties.noResultFound}
			</c:if>
			<c:if test="${empty properties.noResultFound}">    
			No result found
			</c:if>
	</p>
	</c:if>
	<hr class="hr-light-gray">
	<cq:include path="search-parsys"
		resourceType="foundation/components/parsys" />
</div>

<% }%>
