// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConfiguredListService.java

package com.dess.cq.common.helper;

import com.dess.cq.common.search.models.CommonSearchRequest;
import com.dess.cq.common.search.models.CommonSearchResultWrapper;
import javax.jcr.RepositoryException;

public interface ConfiguredListService
{

    public abstract CommonSearchResultWrapper getConfiguredListResult(CommonSearchRequest commonsearchrequest)
        throws RepositoryException;
}
