// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SearchFilterTag.java

package com.dess.cq.common.search.models;


public class SearchFilterTag
{

    public SearchFilterTag(String tagId, String title, int tagCount, boolean isChecked, int level)
    {
        this.tagId = tagId;
        this.title = title;
        this.tagCount = tagCount;
        this.isChecked = isChecked;
        this.level = level;
    }

    public int getLevel()
    {
        return level;
    }

    public String getTitle()
    {
        return title;
    }

    public String getTagId()
    {
        return tagId;
    }

    public void setTagId(String tagId)
    {
        this.tagId = tagId;
    }

    public int getTagCount()
    {
        return tagCount;
    }

    public void setTagCount(int tagCount)
    {
        this.tagCount = tagCount;
    }

    public boolean isChecked()
    {
        return isChecked;
    }

    public void setChecked(boolean isChecked)
    {
        this.isChecked = isChecked;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public void setLevel(int level)
    {
        this.level = level;
    }

    private String tagId;
    private String title;
    private int tagCount;
    private boolean isChecked;
    private int level;
}
