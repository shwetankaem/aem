// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImageSlider.java

package com.icicipru.sightly.bean;


public class ImageSlider
{

    public ImageSlider()
    {
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getDeskPath()
    {
        return deskPath;
    }

    public void setDeskPath(String deskPath)
    {
        this.deskPath = deskPath;
    }

    public String getTabPath()
    {
        return tabPath;
    }

    public void setTabPath(String tabPath)
    {
        this.tabPath = tabPath;
    }

    public String getMobPath()
    {
        return mobPath;
    }

    public void setMobPath(String mobPath)
    {
        this.mobPath = mobPath;
    }

    public String getDeskAlt()
    {
        return deskAlt;
    }

    public void setDeskAlt(String deskAlt)
    {
        this.deskAlt = deskAlt;
    }

    public String getTabAlt()
    {
        return tabAlt;
    }

    public void setTabAlt(String tabAlt)
    {
        this.tabAlt = tabAlt;
    }

    public String getMobAlt()
    {
        return mobAlt;
    }

    public void setMobAlt(String mobAlt)
    {
        this.mobAlt = mobAlt;
    }

    public String getDeskMap()
    {
        return deskMap;
    }

    public void setDeskMap(String deskMap)
    {
        this.deskMap = deskMap;
    }

    public String getTabMap()
    {
        return tabMap;
    }

    public void setTabMap(String tabMap)
    {
        this.tabMap = tabMap;
    }

    private String title;
    private String deskPath;
    private String tabPath;
    private String mobPath;
    private String deskAlt;
    private String tabAlt;
    private String mobAlt;
    private String deskMap;
    private String tabMap;
}
