// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FooterLinks.java

package com.icicipru.components.model;

import java.util.ArrayList;
import java.util.List;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Referenced classes of package com.icicipru.components.model:
//            Link

public class FooterLinks
{

    public FooterLinks()
    {
    }

    public String getFooterTitle()
    {
        return footerTitle;
    }

    public void setFooterTitle(String footerTitle)
    {
        this.footerTitle = footerTitle;
    }

    public String[] getPartnerlinks()
    {
        return partnerlinks;
    }

    public void setPartnerlinks(String partnerlinks[])
    {
        this.partnerlinks = partnerlinks;
    }

    public List getLinks()
    {
        return links;
    }

    public void setLinks(List links)
    {
        this.links = links;
    }

    protected void init()
        throws Exception
    {
        links = new ArrayList();
        if(getPartnerlinks().length > 0)
            try
            {
                String as[] = getPartnerlinks();
                int i = as.length;
                for(int j = 0; j < i; j++)
                {
                    String Obj = as[j];
                    JSONObject jsonObject = new JSONObject(Obj);
                    Link link = new Link();
                    link.setTitle(jsonObject.getString("text"));
                    link.setLink(jsonObject.getString("url"));
                    links.add(link);
                }

            }
            catch(JSONException je)
            {
                LOGGER.error("JSONException:", je);
                LOGGER.info("JSONException:", je);
            }
            catch(Exception e)
            {
                LOGGER.error("Exception:", e);
                LOGGER.info("Exception:", e);
            }
        else
            LOGGER.debug("stringArray length found to be empty");
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/components/model/FooterLinks);
    public String footerTitle;
    private String partnerlinks[];
    public List links;

}
