<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false"%>
<c:if test="${wcmEditMode || empty wcmDisabledMode}">
    <div class="modal-header">
        <button type="button" class="close btn btn-link btn-never-block icon-xl" data-dismiss="modal">
            <span class="glyphicon glyphicon-remove"><span class="sr-only">Close layer</span></span>
        </button>
        <h1 class="modal-title" id="modal-title-${properties.modalid}">${properties.modaltitle}</h1>
    </div>

    <div class="modal-body">
        <cq:include path="modal-body-${properties.modalid}" resourceType="foundation/components/parsys"/>
    </div>

    <div class="modal-footer">
        <cq:include path="modal-footer-${properties.modalid}" resourceType="foundation/components/parsys"/>
    </div>
</c:if>