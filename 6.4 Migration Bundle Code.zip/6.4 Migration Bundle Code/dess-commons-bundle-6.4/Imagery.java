// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Imagery.java

package com.dess.cq.common.models;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import java.util.*;
import javax.jcr.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Imagery
{

    public Imagery()
    {
    }

    public Map getResponsiveImageRenditions(String anImagePath, List aScenario, Session aSession, SlingHttpServletRequest aSlingRequest)
    {
        Map aRenditions = new HashMap();
        try
        {
            javax.jcr.Node imageNode = aSession.getNode(anImagePath);
            if(null != imageNode)
            {
                ResourceResolver resourceResolver = aSlingRequest.getResourceResolver();
                Resource anImageResource = resourceResolver.getResource(anImagePath);
                if(null != anImageResource)
                {
                    Asset anAsset = (Asset)anImageResource.adaptTo(com/day/cq/dam/api/Asset);
                    for(Iterator iterator = aScenario.iterator(); iterator.hasNext();)
                    {
                        String aResolution = (String)iterator.next();
                        String imageName = (new StringBuilder()).append("cq5dam.web.").append(aResolution).append(".jpeg").toString();
                        Rendition renditionImage = anAsset.getRendition(imageName);
                        if(null != renditionImage)
                        {
                            String renditionImagePath = renditionImage.getPath();
                            aRenditions.put(aResolution, renditionImagePath);
                        } else
                        {
                            aRenditions.put(aResolution, anImagePath);
                        }
                    }

                }
            }
        }
        catch(PathNotFoundException pathNotFoundException)
        {
            LOGGER.error("PathNotFoundException :: getResponsiveImageRenditions :: {}", pathNotFoundException.getMessage());
        }
        catch(RepositoryException repositoryException)
        {
            LOGGER.error("RepositoryException :: getResponsiveImageRenditions :: {}", repositoryException.getMessage());
        }
        return aRenditions;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/models/Imagery);
    private static final String RESOLUTION_960_304 = "960.304";
    private static final String RESOLUTION_640_203 = "640.203";
    private static final String RESOLUTION_1480_468 = "1480.468";
    private static final String RESOLUTION_1920_608 = "1920.608";
    private static final String RESOLUTION_290_92 = "290.92";
    private static final String RESOLUTION_960_540 = "960.540";
    private static final String RESOLUTION_640_360 = "640.360";
    private static final String RESOLUTION_1920_1080 = "1920.1080";
    private static final String RESOLUTION_1480_833 = "1480.833";
    private static final String RESOLUTION_290_163 = "290.163";
    private static final String RESOLUTION_640_331 = "640.331";
    private static final String RESOLUTION_960_497 = "960.497";
    private static final String RESOLUTION_1920_994 = "1920.994";
    private static final String RESOLUTION_1480_766 = "1480.766";
    private static final String RESOLUTION_290_203 = "290.203";
    private static final String RESOLUTION_290_150 = "290.150";
    private static final String RESOLUTION_640_640 = "640.640";
    private static final String RESOLUTION_960_960 = "960.960";
    private static final String RESOLUTION_290_290 = "290.290";
    private static final String CQ5DAM_WEB = "cq5dam.web.";
    private static final String IMAGE_JPEG = ".jpeg";
    public static final List SCENARIO_1 = new ArrayList(Arrays.asList(new String[] {
        "960.304", "640.203", "1480.468", "1920.608", "290.92"
    }));
    public static final List SCENARIO_2 = new ArrayList(Arrays.asList(new String[] {
        "960.540", "640.360", "1480.833", "1920.1080", "290.163"
    }));
    public static final List SCENARIO_3 = new ArrayList(Arrays.asList(new String[] {
        "640.360", "960.540", "1920.1080", "1480.833", "290.163"
    }));
    public static final List SCENARIO_4 = new ArrayList(Arrays.asList(new String[] {
        "640.203", "960.304", "1920.608", "1480.468", "290.92"
    }));
    public static final List SCENARIO_5 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "960.497", "1920.994", "1480.766", "290.150"
    }));
    public static final List SCENARIO_6 = new ArrayList(Arrays.asList(new String[] {
        "640.360", "960.540", "1480.833", "290.163"
    }));
    public static final List SCENARIO_7 = new ArrayList(Arrays.asList(new String[] {
        "640.203", "960.304", "1480.468", "290.92", "290.203"
    }));
    public static final List SCENARIO_8 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "960.497", "1480.766", "290.150"
    }));
    public static final List SCENARIO_9 = new ArrayList(Arrays.asList(new String[] {
        "640.640", "960.960", "290.290"
    }));
    public static final List SCENARIO_10 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "960.497", "1920.994", "1480.766", "290.150"
    }));
    public static final List SCENARIO_11 = new ArrayList(Arrays.asList(new String[] {
        "960.304", "640.203", "1480.468", "290.92"
    }));
    public static final List SCENARIO_12 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "1480.766", "960.497", "1920.994", "290.150"
    }));
    public static final List SCENARIO_13 = new ArrayList(Arrays.asList(new String[] {
        "1480.833", "960.540", "640.360", "1920.1080", "290.163"
    }));
    public static final List SCENARIO_14 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "960.497", "1920.994", "1480.766", "290.150"
    }));
    public static final List SCENARIO_15 = new ArrayList(Arrays.asList(new String[] {
        "640.331", "960.497", "1480.766", "290.150"
    }));

}
