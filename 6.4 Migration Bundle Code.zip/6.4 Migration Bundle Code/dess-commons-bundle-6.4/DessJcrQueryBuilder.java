// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DessJcrQueryBuilder.java

package com.dess.cq.common.services;

import com.day.cq.search.result.SearchResult;
import java.util.List;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.Session;

public interface DessJcrQueryBuilder
{

    public abstract SearchResult getResults(Map map, Session session);

    public abstract SearchResult getResults(Map map, Session session, long l, long l1);

    public abstract long getCurrentPageModals(String s, Session session);

    public abstract List getCurrentPageIframe(String s, Session session);

    public abstract boolean isResourceAvailInCurrentPage(String s, String s1, Session session);

    public abstract Node getDialogInfoNode(Session session, String s, String s1);
}
