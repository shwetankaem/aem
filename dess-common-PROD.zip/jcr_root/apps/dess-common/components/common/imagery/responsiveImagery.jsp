<%@include file="/apps/dess-common/components/global.jsp"%><%
%>
<%@page import="com.dess.cq.common.models.Imagery"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.HashMap"%>
<%@page import="java.util.Arrays"%>
<%
    Session session = resource.getResourceResolver().adaptTo(Session.class);
    Imagery imagery = new Imagery();
	Map<String, String> resImages = new HashMap<String, String>();
%>
	<c:set var="altText" value="alt=\"${properties.imagealttext}\""/>
	<dess:cleanHTMLFragment>
	<c:choose>
        <c:when test="${properties.pagelocation eq 'scenario-1'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_1, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1920.608") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("290.92") %> 1x, <%=resImages.get("640.203") %> 2x, <%=resImages.get("960.304") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.92") %>" srcset="<%=resImages.get("290.92") %>" ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.304") %>" srcset="<%=resImages.get("960.304") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}"  src="<%=resImages.get("640.203") %>" srcset="<%=resImages.get("640.203") %>" ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-2'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_2, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1480.833") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1920.1080") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1480.833") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("290.163") %> 1x, <%=resImages.get("640.360") %> 2x, <%=resImages.get("960.540") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.163") %>" srcset="<%=resImages.get("290.163") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.540") %>" srcset="<%=resImages.get("960.540") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.360") %>" srcset="<%=resImages.get("640.360") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-3'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_3, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("960.540") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1920.1080") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1480.833") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("290.163") %> 1x, <%=resImages.get("640.360") %> 2x, <%=resImages.get("960.540") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.163") %>" srcset="<%=resImages.get("290.163") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.540") %>" srcset="<%=resImages.get("960.540") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.360") %>" srcset="<%=resImages.get("640.360") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-4'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_4, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("960.304") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1920.608") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("290.92") %> 1x, <%=resImages.get("640.203") %> 2x, <%=resImages.get("960.304") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.203") %>" srcset="<%=resImages.get("290.203") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.304") %>" srcset="<%=resImages.get("960.304") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.203") %>" srcset="<%=resImages.get("640.203") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-5'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_5, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1920.994") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>" ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>" ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-6'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_6, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("960.540") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("960.540") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1480.833") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("290.163") %> 1x, <%=resImages.get("640.360") %> 2x, <%=resImages.get("960.540") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.163") %>" srcset="<%=resImages.get("290.163") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.540") %>" srcset="<%=resImages.get("960.540") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.360") %>" srcset="<%=resImages.get("640.360") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-7'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_7, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("960.304") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("960.304") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("290.92") %> 1x, <%=resImages.get("640.203") %> 2x, <%=resImages.get("960.304") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.203") %>" srcset="<%=resImages.get("290.203") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.304") %>" srcset="<%=resImages.get("960.304") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.203") %>" srcset="<%=resImages.get("640.203") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-8'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_8, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>" ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-9'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_9, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.640") %>, <%=resImages.get("960.960") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.640") %>, <%=resImages.get("960.960") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("640.640") %>, <%=resImages.get("960.960") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.640") %>, <%=resImages.get("290.290") %> 1x, <%=resImages.get("640.640") %> 2x, <%=resImages.get("960.960") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.290") %>" srcset="<%=resImages.get("290.290") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.960") %>" srcset="<%=resImages.get("960.960") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.640") %>" srcset="<%=resImages.get("640.640") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-10'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_10, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1920.994") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-11'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_11, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("960.304") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.304") %>, <%=resImages.get("1480.468") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.203") %>, <%=resImages.get("290.92") %> 1x, <%=resImages.get("640.203") %> 2x, <%=resImages.get("960.304") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.203") %>" srcset="<%=resImages.get("290.203") %>"   ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.304") %>" srcset="<%=resImages.get("960.304") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.203") %>" srcset="<%=resImages.get("640.203") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-12'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_12, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("1480.766") %>, <%=resImages.get("1920.994") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>" ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>" ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>" ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-13'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_13, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("1480.833") %>, <%=resImages.get("1920.1080") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1920.1080") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.540") %>, <%=resImages.get("1480.833") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.360") %>, <%=resImages.get("290.163") %> 1x, <%=resImages.get("640.360") %> 2x, <%=resImages.get("960.540") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.163") %>" srcset="<%=resImages.get("290.163") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.540") %>" srcset="<%=resImages.get("960.540") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.360") %>" srcset="<%=resImages.get("640.360") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-14'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_14, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1920.994") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
        <c:when test="${properties.pagelocation eq 'scenario-15'}">
        <%
        	resImages = imagery.getResponsiveImageRenditions(properties.get("resImgPath", String.class), Imagery.SCENARIO_15, session, slingRequest);
        %>
            <picture>
                <!--[if IE 9]><video style="display: none;"><![endif]-->
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 992px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("960.497") %> 2x" media="(min-width: 767px)">
                <source srcset="<%=resImages.get("960.497") %>, <%=resImages.get("1480.766") %> 2x" media="(min-width: 510px)">
                <source srcset="<%=resImages.get("640.331") %>, <%=resImages.get("290.150") %> 1x, <%=resImages.get("640.331") %> 2x, <%=resImages.get("960.497") %> 3x" media="(min-width: 320px)">
                <!--[if IE 9]></video><![endif]-->
                <img class="hidden-xs-ie8 res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("290.150") %>" srcset="<%=resImages.get("290.150") %>"  ${altText}>
                <!--[if IE 8]>
				<img class="hidden-xs res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("960.497") %>" srcset="<%=resImages.get("960.497") %>"  ${altText}>
				<img class="hidden-sm hidden-md hidden-lg res-img ${properties.classappend} ${properties.showonprint eq 'true'?'':'hidden-print'}" src="<%=resImages.get("640.331") %>" srcset="<%=resImages.get("640.331") %>"  ${altText}>
				<![endif]-->
            </picture>
        </c:when>
    </c:choose>
    </dess:cleanHTMLFragment>    