<%--

  Panels component.

--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%><%
%><%@page session="false" %>
<%@page session="false" trimDirectiveWhitespaces="false"%>
<%@page import="com.dess.cq.common.models.Imagery"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.HashMap"%>
<%@page import="java.util.Arrays"%>
<%@taglib prefix="dess" uri="http://dess.co.in/desscommon"%>

<%--the jsp is not completely implemented, waiting for wireframe.--%>
<c:if test="${wcmEditMode}">
	<cq:includeClientLib categories="author.dess.common.components.panels"/>
</c:if>

	<%
    Session session = resource.getResourceResolver().adaptTo(Session.class);
    Imagery imagery = new Imagery();
	Map<String, String> resImages = new HashMap<String, String>();
    %>

<c:if test="${properties.activateid}">
<c:set var="idpanel" value="id=\"${properties.panelid}\""/>
</c:if>

<c:choose>
    <c:when test="${properties.panellink}">
        <dess:cleanHTMLFragment>
        <a href="${fn:length(properties.panelurl) > 0 ? properties.panelurl : '#' }" class="panel ${empty properties.selectstyle?'':properties.selectstyle} ${empty properties.panelaccentcolour?'':properties.panelaccentcolour} ${empty properties.classappend?'':properties.classappend} ${properties.openwindowtype eq "_self"?'':'new-window'} ${properties.showonprint eq 'true' ? '' :'hidden-print'}" ${idpanel} target="${properties.openwindowtype}">
        </dess:cleanHTMLFragment>    
    </c:when>
    <c:otherwise>
		<dess:cleanHTMLFragment>
        <div class="panel ${empty properties.selectstyle?'':properties.selectstyle} ${empty properties.panelaccentcolour?'':properties.panelaccentcolour} ${empty properties.classappend?'':properties.classappend} ${properties.showonprint eq 'true' ? '' :'hidden-print'}" ${idpanel}>
		</dess:cleanHTMLFragment>
    </c:otherwise>
</c:choose>    
    	<c:if test="${properties.selectstyle == 'panel-section panel-icon' || properties.selectstyle == 'panel-section panel-icon panel-icon-alt' || properties.selectstyle == 'panel-section panel-img'}">

    		<div class="panel-header">
    			<c:choose>

				<c:when test="${properties.selectstyle == 'panel-section panel-img'}">
                    <cq:include script="/apps/dess-common/components/imagery/responsiveImagery.jsp"/>
				</c:when>
                <c:otherwise>
                    <span class="icon ${empty properties.iconref?'':properties.iconref}"></span>
				</c:otherwise>
                </c:choose>
        	</div>
    	</c:if>
            <div class="panel-body">
              <cq:include path="paneltext" resourceType="foundation/components/parsys" />
            </div>
<c:choose>
    <c:when test="${properties.panellink}">
        </a>
    </c:when>
    <c:otherwise>
        </div>
    </c:otherwise>
</c:choose>



	
