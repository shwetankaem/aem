// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PopularListService.java

package com.dess.cq.common.helper;

import com.day.cq.wcm.api.Page;
import com.dess.cq.common.search.models.CommonSearchRequest;
import com.dess.cq.common.search.models.CommonSearchResultWrapper;
import javax.jcr.RepositoryException;

public interface PopularListService
{

    public abstract CommonSearchResultWrapper getMostPopularResult(CommonSearchRequest commonsearchrequest, Page page)
        throws RepositoryException;
}
