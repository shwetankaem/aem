// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HelloServiceImpl.java

package com.icicipru.core.impl;

import com.icicipru.core.HelloService;
import org.apache.sling.jcr.api.SlingRepository;

public class HelloServiceImpl
    implements HelloService
{

    public HelloServiceImpl()
    {
    }

    public String getRepositoryName()
    {
        return repository.getDescriptor("jcr.repository.name");
    }

    protected void bindRepository(SlingRepository paramSlingRepository)
    {
        repository = paramSlingRepository;
    }

    protected void unbindRepository(SlingRepository paramSlingRepository)
    {
        if(repository == paramSlingRepository)
            repository = null;
    }

    private SlingRepository repository;
}
