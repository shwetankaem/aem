<%--

  Horizontal Line component.

--%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>
<%@page session="false" %>

<dess:cleanHTMLFragment>
	<hr class="${properties.styleclass} ${properties.classappends} ${properties.showonprint eq 'true'?'':'hidden-print'}"/>
</dess:cleanHTMLFragment>


