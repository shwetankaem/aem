// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SubNavigationService.java

package com.dess.cq.common.helper;

import com.day.cq.search.result.SearchResult;
import java.util.Map;
import javax.jcr.Session;

public interface SubNavigationService
{

    public abstract SearchResult getResults(Map map, Session session);

    public abstract SearchResult getResultsComponentSearch(String s, Session session);
}
