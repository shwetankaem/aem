// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HeaderList.java

package com.icicipru.core;

import java.util.*;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeaderList
{

    public HeaderList()
    {
    }

    public String[] getStringArray()
    {
        return stringArray;
    }

    public void setStringArray(String stringArray[])
    {
        this.stringArray = stringArray;
    }

    public List getHeaderListDetails()
    {
        LOGGER.info("getHeaderListDetails() of HeaderList() STARTS..");
        List headerList = new ArrayList();
        if(getStringArray().length > 0)
        {
            LOGGER.debug((new StringBuilder()).append("stringArray length found to be:").append(getStringArray().length).toString());
            try
            {
                String as[] = getStringArray();
                int i = as.length;
                for(int j = 0; j < i; j++)
                {
                    String Obj = as[j];
                    JSONObject jsonObject = new JSONObject(Obj);
                    Map map = new HashMap();
                    map.put("title", jsonObject.getString("text"));
                    map.put("link", jsonObject.getString("url"));
                    if(jsonObject.has("cssDropdown"))
                        map.put("cssSelect", jsonObject.getString("cssDropdown"));
                    headerList.add(map);
                }

            }
            catch(JSONException je)
            {
                LOGGER.error("JSONException:", je);
                LOGGER.info("JSONException:", je);
            }
            catch(Exception e)
            {
                LOGGER.error("Exception:", e);
                LOGGER.info("Exception:", e);
            }
        } else
        {
            LOGGER.debug("stringArray length found to be empty");
        }
        LOGGER.info("getHeaderListDetails() of HeaderList ENDS");
        return headerList;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/core/HeaderList);
    private String stringArray[];

}
