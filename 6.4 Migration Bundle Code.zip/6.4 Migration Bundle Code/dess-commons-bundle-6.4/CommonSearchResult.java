// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonSearchResult.java

package com.dess.cq.common.search.models;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.search.result.Hit;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import javax.jcr.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.*;

public class CommonSearchResult
{

    public CommonSearchResult(Hit hit, SlingHttpServletRequest request)
        throws RepositoryException
    {
        PageManager pageManager = (PageManager)request.getResourceResolver().adaptTo(com/day/cq/wcm/api/PageManager);
        Session session = (Session)request.getResourceResolver().adaptTo(javax/jcr/Session);
        String resultType = (String)hit.getProperties().get("jcr:primaryType");
        if(resultType.equalsIgnoreCase("dam:AssetContent"))
            setForAssetHit(hit, session);
        else
            setForPageHit(hit, pageManager);
    }

    public CommonSearchResult()
    {
    }

    private void setForPageHit(Hit hit, PageManager pageManager)
        throws RepositoryException
    {
        Page hitPage = pageManager.getContainingPage(hit.getPath());
        Tag tags[] = hitPage.getTags();
        String iconClass = "icon-default";
        Tag arr$[] = tags;
        int len$ = arr$.length;
        int i$ = 0;
        if(i$ < len$)
        {
            Tag tag = arr$[i$];
            iconClass = tag.getDescription();
        }
        resultClass = iconClass;
        resultPath = (new StringBuilder()).append(hit.getPath()).append(".html").toString();
        resultTitle = hitPage.getTitle();
        resultDescription = hitPage.getDescription();
    }

    private void setForAssetHit(Hit hit, Session session)
        throws RepositoryException
    {
        Asset asset = (Asset)hit.getResource().adaptTo(com/day/cq/dam/api/Asset);
        Node metaDataNode = session.getNode((new StringBuilder()).append(hit.getPath()).append("/jcr:content/metadata").toString());
        String assetDescription = getAssetProperty(metaDataNode, "dc:description");
        String assetTitle = getAssetProperty(metaDataNode, "dc:title");
        if(assetTitle.equalsIgnoreCase(""))
            assetTitle = asset.getName();
        long assetSize = asset.getOriginal().getSize() / 1024L;
        String unit = "K";
        if(assetSize > 1024L)
        {
            assetSize /= 1024L;
            unit = "M";
        }
        String mimeType = asset.getMimeType();
        String docType = "";
        String resultClass = "";
        if(mimeType.contains("image"))
        {
            docType = "IMAGE";
            resultClass = "icon-default";
        } else
        if(mimeType.contains("pdf"))
        {
            docType = "PDF";
            resultClass = "icon-pdf";
        }
        this.assetSize = assetSize;
        resultDescription = assetDescription;
        this.unit = unit;
        this.mimeType = mimeType;
        this.docType = docType;
        resultPath = hit.getPath();
        isAsset = "true";
        this.resultClass = resultClass;
        resultTitle = assetTitle;
        target = "blank";
    }

    public String getResultTitle()
    {
        return resultTitle;
    }

    public void setResultTitle(String resultTitle)
    {
        this.resultTitle = resultTitle;
    }

    public String getResultDescription()
    {
        return resultDescription;
    }

    public void setResultDescription(String resultDescription)
    {
        this.resultDescription = resultDescription;
    }

    public String getResultPath()
    {
        return resultPath;
    }

    public void setResultPath(String resultPath)
    {
        this.resultPath = resultPath;
    }

    public String getResultClass()
    {
        return resultClass;
    }

    public void setResultClass(String resultClass)
    {
        this.resultClass = resultClass;
    }

    public String getTarget()
    {
        return target;
    }

    public void setTarget(String target)
    {
        this.target = target;
    }

    public String getIsAsset()
    {
        return isAsset;
    }

    public void setIsAsset(String isAsset)
    {
        this.isAsset = isAsset;
    }

    public String getDocType()
    {
        return docType;
    }

    public void setDocType(String docType)
    {
        this.docType = docType;
    }

    public String getMimeType()
    {
        return mimeType;
    }

    public void setMimeType(String mimeType)
    {
        this.mimeType = mimeType;
    }

    public long getAssetSize()
    {
        return assetSize;
    }

    public void setAssetSize(long assetSize)
    {
        this.assetSize = assetSize;
    }

    public String getUnit()
    {
        return unit;
    }

    public void setUnit(String unit)
    {
        this.unit = unit;
    }

    private String getAssetProperty(Node metaDataNode, String propertyName)
        throws RepositoryException
    {
        String propertyValue = "";
        if(metaDataNode.hasProperty(propertyName))
            if(metaDataNode.getProperty(propertyName).isMultiple())
            {
                if(metaDataNode.getProperty(propertyName).getValues().length > 0)
                    propertyValue = metaDataNode.getProperty(propertyName).getValues()[0].getString();
            } else
            {
                propertyValue = metaDataNode.getProperty(propertyName).getValue().getString();
            }
        return propertyValue;
    }

    public int getPageViews()
    {
        return pageViews;
    }

    public void setPageViews(int pageViews)
    {
        this.pageViews = pageViews;
    }

    private String resultTitle;
    private String resultDescription;
    private String resultPath;
    private String resultClass;
    private String target;
    private String isAsset;
    private String docType;
    private String mimeType;
    private long assetSize;
    private String unit;
    private int pageViews;
}
