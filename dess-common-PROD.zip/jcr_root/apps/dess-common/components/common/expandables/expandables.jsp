<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page import="com.day.cq.wcm.foundation.Placeholder"%>
<%@page
	import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>
<%@page session="false"%>
<c:if test="${wcmEditMode}">
	<cq:includeClientLib categories="author.dess.common.components.expandables" />
</c:if>
<c:choose>
	<c:when test="${properties.expandabletype eq 'expandable'}">
<% 
List<Map<String, String>> valueMap= MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"expandableitems");

%>
		<c:set var="expandableItems" value="<%=valueMap%>" />
		<c:if test="${properties.expansiontype eq 'accordion'}">
			<c:set var="extraAttrAccordion" value="data-parent=\" ${'#'}${properties.groupid}\""/>
		</c:if>
        <dess:cleanHTMLFragment>
		<div class="panel-group ${properties.showonprint eq 'true' ? '' :'hidden-print'}" id="${properties.groupid}">
        </dess:cleanHTMLFragment>    
	 		<c:forEach varStatus="vs" items="${expandableItems}"
				var="expandableItem">
 				<div class="panel panel-default">
                    <c:if test="${expandableItem['showloadingindicator']}">
                         <c:set var="datrattr" value="data-ref=\"${currentNode.path}/par-${expandableItem['expandableitemid']}.html\""/>
                    </c:if>
					<dess:cleanHTMLFragment>
                    <div class="panel-heading ${expandableItem['showloadingindicator'] ? 'js-ajax-expandable' : '' }" ${datrattr}>
					</dess:cleanHTMLFragment>
						<a data-toggle="collapse" ${extraAttrAccordion}
                        href="#${expandableItem['expandableitemid']}" class="collapsed ${not empty expandableItem['numblock']? 'number-blocks' : ''}">
							<${expandableItem['headertag']} class="panel-title">
                                <c:if test="${not empty expandableItem['numblock']}">
                                    <span class="number-block">${expandableItem['numblock']}</span>
                            	</c:if>
							${expandableItem['headertext']} </${expandableItem['headertag']}>
                            <c:if test="${not empty expandableItem['introtext']}">
								<p>${expandableItem['introtext']}</p>
                            </c:if>
                            <span class="glyphicon glyphicon-plus pull-right"><span class="sr-only">(Expand content)</span></span> <span class="glyphicon icon-minus pull-right">
                            <span class="sr-only">(Minimise content)</span></span>
							<span aria-hidden="false" class="icon icon-loading hidden"><span class="sr-only">(Content loading)</span></span>
						</a>
					</div>
					<div id="${expandableItem['expandableitemid']}"
						class="panel-collapse collapse" style="height: 0px;">
						<div class="panel-body"
							id="panel${expandableItem['expandableitemid']}">
                                <c:if test="${wcmEditMode || !expandableItem['showloadingindicator']}">
								<cq:include path="par-${expandableItem['expandableitemid']}"
									resourceType="foundation/components/parsys" />
							</c:if>
						</div>
					</div>
				</div>
			</c:forEach>
		</div>
	</c:when>
	<c:otherwise>
 					<c:if test="${properties.showloadingreadme eq 'true'}">
                        <c:set var="datrattr" value="data-ref=\"${currentNode.path}/par-${properties.groupid}.html\""/>
                    </c:if>
		<p>${properties.readmeintrotext}
            <span class="read-more"> <a ${properties.showloadingreadme ? 'class="js-ajax-expandable"' : 'class="js-read-more"' } data-toggle="collapse"
                href="#${properties.readmoreid}" ${datrattr} >Read more <span class="sr-only">${properties.screenreadertext}</span></a>
			</span>
		</p>
		<div id="${properties.readmoreid}" class="read-more-box collapse">
            <c:if test="${wcmEditMode || !properties.showloadingreadme}">
				<cq:include path="par-${properties.groupid}"
					resourceType="foundation/components/parsys" />
			</c:if>
		</div>
	</c:otherwise>
</c:choose>