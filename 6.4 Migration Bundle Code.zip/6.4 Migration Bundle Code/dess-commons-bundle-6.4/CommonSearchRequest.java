// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonSearchRequest.java

package com.dess.cq.common.search.models;

import org.apache.sling.api.SlingHttpServletRequest;

public class CommonSearchRequest
{

    public CommonSearchRequest(SlingHttpServletRequest request)
    {
        offset = getDefaultValue(request, "offset", "0");
        limit = getDefaultValue(request, "limit", "25");
        searchPath = getDefaultValue(request, "selectArea", "");
        listType = getDefaultValue(request, "listType", "");
        tagSearch = getDefaultValue(request, "tagSearch", "");
        searchInput = getDefaultValue(request, "searchInput", "");
        this.request = request;
        tags = getDefaultValues(request, "sectionTag");
        locationTags = getDefaultValues(request, "locationTag");
        if(null != tagSearch && !tagSearch.equalsIgnoreCase(""))
            tagSearchArray = tagSearch.split(",");
    }

    public CommonSearchRequest()
    {
    }

    public String getSearchInput()
    {
        return searchInput;
    }

    public void setSearchInput(String searchInput)
    {
        this.searchInput = searchInput;
    }

    public String getSearchPath()
    {
        return searchPath;
    }

    public void setSearchPath(String searchPath)
    {
        this.searchPath = searchPath;
    }

    public String getOffset()
    {
        return offset;
    }

    public void setOffset(String offset)
    {
        this.offset = offset;
    }

    public String getLimit()
    {
        return limit;
    }

    public void setLimit(String limit)
    {
        this.limit = limit;
    }

    public String getListType()
    {
        return listType;
    }

    public void setListType(String listType)
    {
        this.listType = listType;
    }

    public String getTagSearch()
    {
        return tagSearch;
    }

    public void setTagSearch(String tagSearch)
    {
        this.tagSearch = tagSearch;
    }

    public SlingHttpServletRequest getRequest()
    {
        return request;
    }

    public void setRequest(SlingHttpServletRequest request)
    {
        this.request = request;
    }

    public String[] getTags()
    {
        return tags;
    }

    public void setTags(String tags[])
    {
        this.tags = tags;
    }

    public String[] getLocationTags()
    {
        return locationTags;
    }

    public void setLocationTags(String locationTags[])
    {
        this.locationTags = locationTags;
    }

    public String[] getTagSearchArray()
    {
        return tagSearchArray;
    }

    public void setTagSearchArray(String tagSearchArray[])
    {
        this.tagSearchArray = tagSearchArray;
    }

    public String getDefaultValue(SlingHttpServletRequest request, String parameterName, String defaultValue)
    {
        if(request.getParameter(parameterName) != null)
            return request.getParameter(parameterName);
        else
            return defaultValue;
    }

    public String[] getDefaultValues(SlingHttpServletRequest request, String parameterName)
    {
        if(request.getParameterValues(parameterName) != null)
            return request.getParameterValues(parameterName);
        else
            return getDefaultStringArray();
    }

    private String[] getDefaultStringArray()
    {
        String array[] = new String[1];
        array[0] = "";
        return array;
    }

    private String searchInput;
    private String searchPath;
    private String offset;
    private String limit;
    private String listType;
    private String tagSearch;
    private SlingHttpServletRequest request;
    private String tags[];
    private String locationTags[];
    private String tagSearchArray[];
    private static final int CONSTANT_ZERO = 0;
}
