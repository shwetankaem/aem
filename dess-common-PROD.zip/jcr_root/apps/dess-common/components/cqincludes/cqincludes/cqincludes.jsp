<%--

  cqincludes component.

  Component to reuse dialog structure.



--%><%
%><%@include file="/libs/foundation/global.jsp"%><%
%><%@page session="false" %><%
%><%



    // TODO add you code here
%>