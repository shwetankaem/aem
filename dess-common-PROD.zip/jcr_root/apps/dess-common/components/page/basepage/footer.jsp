<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>

<footer id="" class=""> 
    <cq:include path="common-footer" resourceType="foundation/components/iparsys"/>      
</footer>

<cq:include script="bottomlibs.jsp"/>
