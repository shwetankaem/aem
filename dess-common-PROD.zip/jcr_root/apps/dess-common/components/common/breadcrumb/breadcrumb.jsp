<%@page session="false"%><%--
  Copyright 1997-2008 Day Management AG
  Barfuesserplatz 6, 4001 Basel, Switzerland
  All Rights Reserved.

  This software is the confidential and proprietary information of
  Day Management AG, ("Confidential Information"). You shall not
  disclose such Confidential Information and shall use it only in
  accordance with the terms of the license agreement you entered into
  with Day.

  ==============================================================================

  Breadcrumb component

  Draws the breadcrumb

--%><%@include file="/apps/dess-common/components/global.jsp"%>


<nav role="navigation">
    <p id="breadcrumblabel" class="sr-only">You are here:</p>
      <ol id="breadcrumb" class="breadcrumb" aria-labelledby="breadcrumblabel">
<%

    // get starting point of trail
    long level = currentStyle.get("absParent", 1L);
    long endLevel = currentStyle.get("relParent", 0L);

    int currentLevel = currentPage.getDepth();
    Page trail = null;
    String title = null;
    while (level < currentLevel - endLevel) {
    	trail = currentPage.getAbsoluteParent((int) level);
        if (trail == null) {
            break;
        }
        
        if(!trail.isHideInNav()) {
         title = trail.getNavigationTitle();
        if (title == null || title.equals("")) {
            title = trail.getNavigationTitle();
        }
        if (title == null || title.equals("")) {
            title = trail.getTitle();
        }
        if (title == null || title.equals("")) {
            title = trail.getName();
        }
        if(level < (currentLevel - endLevel)-1){
        %>
        <li><a href="<%= xssAPI.getValidHref(trail.getPath()+".html") %>" title="<%=title%>"><%= xssAPI.encodeForHTML(title) %></a>
        </li>
        <%
        } else {%>
          <li class="active"><%= xssAPI.encodeForHTML(title) %></li>
        <%}
        }
        level++;
    }

%>
</ol>
</nav>


