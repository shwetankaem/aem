(function() { 
var originalCalculateTableConfig = CQ.form.rte.plugins.TablePropertiesDialog.prototype.calculateTableConfig;
CQ.Ext.override(CQ.form.rte.plugins.TablePropertiesDialog,{
	calculateTableConfig: function() {
        if(this.editContext.iFrame?this.editContext.iFrame.hasAttribute("configuredforcommon"):""){
        var com = CUI.rte.Common;
        var tableConfig;
        if (this.table) {
            tableConfig = { };
            this.propertyItems.each(function(item) {
                var id = item.itemId;
                if (id == "tableStyle") {
                    var styleCnt = this.tableStyles.length;
                    var classNames = CUI.rte.Common.parseCSS(this.table);
                    var isFound = false;
                    for (var i = 0; (i < classNames.length) && !isFound; i++) {
                        for (var s = 0; s < styleCnt; s++) {
                            var style = this.tableStyles[s];
                            if (style.cssName == classNames[i]) {
                                tableConfig[id] = classNames[i];
                                isFound = true;
                                break;
                            }
                        }
                    }
                } else {
                    if (item.styleAttrib) {
                        tableConfig[id] = this.table.style[item.styleAttrib];
                    } else {
                        if(item.itemId=='width' || item.itemId=='height' || item.itemId=='border' || item.itemId=='cellpadding' || item.itemId=='cellspacing' )
                    	{
                        item.setVisible(false);
	                    }
	                    var propName = item.domProp || id;
                        tableConfig[id] = com.getAttribute(this.table, propName);
                    }
                }
                return true;
            }, this);
        } else {
            tableConfig = this.defaultValues;
        }
        return tableConfig;
 }else{
 originalCalculateTableConfig.apply(this);
 }
}
});
}());