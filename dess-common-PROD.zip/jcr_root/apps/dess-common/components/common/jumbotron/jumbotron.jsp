<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false" trimDirectiveWhitespaces="false"%>
<div class="jumbotron">
    <img src="/content/dam/geometrixx/banners/call_center.jpg" class=""/>
  <cq:include script="../headings/headings.jsp"/>
  <cq:include path="jumbotron-body" resourceType="foundation/components/parsys"/>
  <c:if test="${not empty properties.visibleText}">
  	<p><cq:include script="../linksbuttons/linksbuttons.jsp"/></p>
  </c:if>

</div>

