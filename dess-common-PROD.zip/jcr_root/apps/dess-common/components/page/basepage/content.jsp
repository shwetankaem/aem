<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<cq:include path="content-body" resourceType="foundation/components/parsys"/>  