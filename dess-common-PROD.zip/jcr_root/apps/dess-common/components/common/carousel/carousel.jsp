<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false"%>
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>

<% 

List<Map<String, String>> valueMap= MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"carouselImages");


%>

<c:choose>
    <c:when test="${properties.appearwhenprinted ne 'true' || not empty properties.cssoverride}">
        <c:choose>
            <c:when test="${properties.appearwhenprinted ne 'true' && empty properties.cssoverride}">
                <c:set var="classesdf" value="hidden-print"/>
            </c:when>
            <c:when test="${properties.appearwhenprinted eq 'true' && not empty properties.cssoverride}">
                <c:set var="classesdf" value="${properties.classoverridelb}"/>
            </c:when>
            <c:when test="${properties.appearwhenprinted ne 'true' && not empty properties.cssoverride}">
                <c:set var="classesdf" value="hidden-print ${properties.classoverridelb}"/>
            </c:when>
        </c:choose>
    </c:when>
    <c:otherwise>
        <c:set var="classesdf" value=""/>
    </c:otherwise>    
</c:choose>    


<c:set var="carouselImages" value="<%=valueMap%>" />
<c:choose>
<c:when test="${not empty carouselImages && fn:length(carouselImages) gt 0}">
    <div id="carousel-example-generic" class="carousel slide ${not empty classesdf ? classesdf : ''}" data-ride="carousel">
  <ol class="carousel-indicators">
    <c:forEach varStatus="loop1" items="${carouselImages}" var="carouselImages1">
        <c:set var="class" value="class=\"active\"" />
        <li data-target="#carousel-example-generic" data-slide-to="${loop1.index}" ${loop1.index eq 0 ? class : ''}></li>
    </c:forEach>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
      <c:forEach varStatus="loop2" items="${carouselImages}" var="carouselImages2">
          <div class="item ${loop2.index eq 0 ? 'active' : ''}">
            <img src="${carouselImages2['slide']}" alt="${carouselImages2['alt']}" />
          <div class="carousel-caption">
              ${carouselImages2['captionText']}
          </div>
        </div>
	  </c:forEach>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</c:when>
	<c:otherwise>
        <c:if test="${wcmEditMode}">
        	Edit Carousel
        </c:if>
	</c:otherwise>
</c:choose>