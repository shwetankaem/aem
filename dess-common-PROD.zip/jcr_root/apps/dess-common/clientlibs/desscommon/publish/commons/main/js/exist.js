/*
* Custom function that is used to check if the dom element exist
*/
$.fn.exists = function(callback) {
  var args = [].slice.call(arguments, 1);

  if (this.length) {
    callback.call(this, args);
  }

  return this;
};

/**
* Returns true if the site is running
* in author mode. CQ.WCM is a global var set by CQ itself in author mode.
*
* @return {Boolean}
*/
$.fn.isAuthor = function() {
    if (typeof CQ !== 'undefined') {
        return (typeof CQ.WCM !== 'undefined');
    }
    return false;
};