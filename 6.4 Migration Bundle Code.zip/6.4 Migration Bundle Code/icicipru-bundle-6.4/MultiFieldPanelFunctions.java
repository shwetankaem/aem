// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MultiFieldPanelFunctions.java

package com.icicipru.utilities.widgets;

import com.adobe.cq.sightly.WCMUsePojo;
import java.util.*;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MultiFieldPanelFunctions extends WCMUsePojo
{

    public MultiFieldPanelFunctions()
    {
    }

    public List getMyHashMap()
    {
        return myHashMap;
    }

    public void activate()
        throws Exception
    {
        String name = (String)get("param1", java/lang/String);
        Resource currentResource = (Resource)get("param2", org/apache/sling/api/resource/Resource);
        myHashMap = getMultiFieldPanelValues(currentResource, name);
    }

    public static List getMultiFieldPanelValues(Resource resource, String name)
    {
        ValueMap map = (ValueMap)resource.adaptTo(org/apache/sling/api/resource/ValueMap);
        List results = new ArrayList();
        if(map.containsKey(name))
        {
            String values[] = (String[])(String[])map.get(name, new String[0]);
            populateResults(results, values);
        }
        return results;
    }

    public static void populateResults(List results, String values[])
    {
        String as[] = values;
        int i = as.length;
        for(int j = 0; j < i; j++)
        {
            String value = as[j];
            try
            {
                JSONObject parsed = new JSONObject(value);
                Map columnMap = new HashMap();
                String key;
                String innerValue;
                for(Iterator iter = parsed.keys(); iter.hasNext(); columnMap.put(key, innerValue))
                {
                    key = (String)iter.next();
                    innerValue = parsed.getString(key);
                }

                results.add(columnMap);
            }
            catch(JSONException e)
            {
                LOGGER.error("Unable to parse JSON {}", e.getMessage());
            }
        }

    }

    public static List getInheritedMultiFieldPanelValues(String inheritedValueMap[])
    {
        List results = new ArrayList();
        if(null != inheritedValueMap)
        {
            String values[] = inheritedValueMap;
            populateResults(results, values);
        }
        return results;
    }

    private List myHashMap;
    public static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/utilities/widgets/MultiFieldPanelFunctions);

}
