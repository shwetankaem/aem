// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SearchServiceImpl.java

package com.dess.cq.common.search.impl;

import com.day.cq.search.*;
import com.day.cq.search.facets.Bucket;
import com.day.cq.search.facets.Facet;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.dess.cq.common.search.SearchService;
import com.dess.cq.common.search.models.*;
import java.util.*;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchServiceImpl
    implements SearchService
{

    public SearchServiceImpl()
    {
    }

    public CommonSearchResultWrapper getResults(CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        return getResultObject(commonSearchRequest);
    }

    private CommonSearchResultWrapper getResultObject(CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        Session session = (Session)commonSearchRequest.getRequest().getResourceResolver().adaptTo(javax/jcr/Session);
        CommonSearchResultWrapper resultWrapper = new CommonSearchResultWrapper();
        if(commonSearchRequest.getTags() == null)
            commonSearchRequest.setTags(getDefaultStringArray());
        if(commonSearchRequest.getLocationTags() == null)
            commonSearchRequest.setLocationTags(getDefaultStringArray());
        int tagCount = commonSearchRequest.getTags().length;
        Map predicateMap = generatePredicateMap(commonSearchRequest);
        SearchResult querySearchResult = executeQuery(predicateMap, session);
        if(querySearchResult != null)
        {
            List hitsList = querySearchResult.getHits();
            if(hitsList != null && !hitsList.isEmpty())
            {
                resultWrapper = generateCountObjectFromResult(querySearchResult, resultWrapper);
                resultWrapper = generatePaginationFromResult(querySearchResult, commonSearchRequest, resultWrapper);
                List resultObjectList = new ArrayList();
                setTagFilterInRequest(commonSearchRequest, tagCount, querySearchResult);
                Hit hit;
                for(Iterator iterator = querySearchResult.getHits().iterator(); iterator.hasNext(); resultObjectList.add(generateResultObjectFromHit(hit, commonSearchRequest.getRequest())))
                    hit = (Hit)iterator.next();

                resultWrapper.setResults(resultObjectList);
            }
        }
        return resultWrapper;
    }

    private void setTagFilterInRequest(CommonSearchRequest commonSearchRequest, int tagCount, SearchResult querySearchResult)
        throws RepositoryException
    {
        TagManager tagManager = (TagManager)commonSearchRequest.getRequest().getResourceResolver().adaptTo(com/day/cq/tagging/TagManager);
        List searchTags = new LinkedList();
        Map facetMap = querySearchResult.getFacets();
        Facet facetForPages = (Facet)facetMap.get("1_group.1_group.1_tagid");
        Facet facetForAsset = (Facet)facetMap.get((new StringBuilder()).append("1_group.1_group.").append(tagCount + 1).append("_tagid").toString());
        Tag commonTagNamespace = tagManager.resolve("/etc/tags");
        List modifiedSearchtags = buildTagTreeAndChildren(commonTagNamespace, facetForPages, facetForAsset, 0, tagManager, searchTags);
        commonSearchRequest.getRequest().setAttribute("tagList", modifiedSearchtags);
    }

    protected String[] getDefaultStringArray()
    {
        String array[] = new String[1];
        array[0] = "";
        return array;
    }

    protected CommonSearchResultWrapper generatePaginationFromResult(SearchResult querySearchResult, CommonSearchRequest commonSearchRequest, CommonSearchResultWrapper resultWrapper)
    {
        long totalResults = querySearchResult.getTotalMatches();
        int totalPagesIndex = 0;
        int limitInInt = Integer.parseInt(commonSearchRequest.getLimit());
        totalPagesIndex = getTotalPagesIndex(totalResults, limitInInt);
        String nextPageAjaxUrl = "";
        String previousPageAjaxUrl = "";
        StringBuilder paginationUrl = getPaginationURL(commonSearchRequest);
        nextPageAjaxUrl = paginationUrl.toString();
        StringBuilder nextPageURL = new StringBuilder(nextPageAjaxUrl);
        previousPageAjaxUrl = paginationUrl.toString();
        StringBuilder previousPageUrl = new StringBuilder(previousPageAjaxUrl);
        nextPageURL.append((new StringBuilder()).append("&offset=").append(Integer.parseInt(commonSearchRequest.getOffset()) + limitInInt).toString());
        int previousOffsetValue = 0;
        if(Integer.parseInt(commonSearchRequest.getOffset()) - limitInInt > 0)
            previousOffsetValue = Integer.parseInt(commonSearchRequest.getOffset()) - limitInInt;
        previousPageUrl.append((new StringBuilder()).append("&offset=").append(previousOffsetValue).toString());
        int currentPageIndex = Integer.parseInt(commonSearchRequest.getOffset()) / limitInInt + 1;
        resultWrapper.setCurrentPageIndex(currentPageIndex);
        resultWrapper.setTotalPages(totalPagesIndex);
        if(currentPageIndex == 1 && currentPageIndex == totalPagesIndex)
            resultWrapper = setPaginationInWrapper(true, true, "", "", resultWrapper);
        else
        if(currentPageIndex == 1)
            resultWrapper = setPaginationInWrapper(true, false, "", nextPageURL.toString(), resultWrapper);
        else
        if(currentPageIndex == totalPagesIndex)
            resultWrapper = setPaginationInWrapper(false, true, previousPageUrl.toString(), "", resultWrapper);
        else
            resultWrapper = setPaginationInWrapper(false, false, previousPageUrl.toString(), nextPageURL.toString(), resultWrapper);
        resultWrapper = setPaginationObject(resultWrapper);
        return resultWrapper;
    }

    private CommonSearchResultWrapper setPaginationInWrapper(boolean prev, boolean next, String prevURL, String nextURL, CommonSearchResultWrapper resultWrapper)
    {
        resultWrapper.setDisablePrevButton(prev);
        resultWrapper.setDisableNextButton(next);
        resultWrapper.setPreviousPageAjaxUrl(prevURL);
        resultWrapper.setNextPageAjaxUrl(nextURL);
        return resultWrapper;
    }

    private StringBuilder getPaginationURL(CommonSearchRequest commonSearchRequest)
    {
        PageManager pageManager = (PageManager)commonSearchRequest.getRequest().getResourceResolver().adaptTo(com/day/cq/wcm/api/PageManager);
        Page requestedPage = pageManager.getContainingPage(commonSearchRequest.getRequest().getResource());
        String searchText = commonSearchRequest.getSearchInput();
        String searchPath = commonSearchRequest.getSearchPath();
        StringBuilder paginationUrl = new StringBuilder();
        paginationUrl.append((new StringBuilder()).append(requestedPage.getPath()).append(".search.html?").toString());
        paginationUrl.append((new StringBuilder()).append("searchInput=").append(searchText).toString());
        paginationUrl.append((new StringBuilder()).append("&selectArea=").append(searchPath).toString());
        paginationUrl.append((new StringBuilder()).append("&limit=").append(commonSearchRequest.getLimit()).toString());
        if(commonSearchRequest.getListType() != null && !commonSearchRequest.getListType().equalsIgnoreCase(""))
            paginationUrl.append((new StringBuilder()).append("&listType=").append(commonSearchRequest.getListType()).toString());
        String as[] = commonSearchRequest.getTags();
        int i = as.length;
        for(int j = 0; j < i; j++)
        {
            String tag = as[j];
            paginationUrl.append((new StringBuilder()).append("&sectionTag=").append(tag).toString());
        }

        as = commonSearchRequest.getLocationTags();
        i = as.length;
        for(int k = 0; k < i; k++)
        {
            String locationTag = as[k];
            paginationUrl.append((new StringBuilder()).append("&locationTag=").append(locationTag).toString());
        }

        if(null != commonSearchRequest.getTagSearchArray() && commonSearchRequest.getTagSearchArray().length > 0)
        {
            String tagArrayString = StringUtils.join(commonSearchRequest.getTagSearchArray(), ",");
            paginationUrl.append((new StringBuilder()).append("&tagSearch=").append(tagArrayString).toString());
        }
        return paginationUrl;
    }

    private int getTotalPagesIndex(long totalResults, int limitInInt)
    {
        if(totalResults % (long)limitInInt == 0L)
            return (int)(totalResults / (long)limitInInt);
        else
            return (int)(totalResults / (long)limitInInt) + 1;
    }

    private CommonSearchResultWrapper setPaginationObject(CommonSearchResultWrapper resultWrapper)
    {
        Pagination paginationObject = new Pagination();
        paginationObject.setHitsPerPage(resultWrapper.getHitsPerPage());
        paginationObject.setHitsCount(resultWrapper.getHitsCount());
        paginationObject.setCurrentPageIndex(resultWrapper.getCurrentPageIndex());
        paginationObject.setSingularResult(resultWrapper.getSingularResult());
        paginationObject.setTotalMatches(resultWrapper.getTotalMatches());
        paginationObject.setTotalPages(resultWrapper.getTotalPages());
        paginationObject.setDisableNextButton(resultWrapper.isDisableNextButton());
        paginationObject.setDisablePrevButton(resultWrapper.isDisablePrevButton());
        paginationObject.setNextPageAjaxUrl(resultWrapper.getNextPageAjaxUrl());
        paginationObject.setPreviousPageAjaxUrl(resultWrapper.getPreviousPageAjaxUrl());
        resultWrapper.setPaginationObject(paginationObject);
        return resultWrapper;
    }

    private Map generatePredicateMap(CommonSearchRequest commonSearchRequest)
    {
        Map predicateMap = new HashMap();
        predicateMap.put("path", commonSearchRequest.getSearchPath());
        predicateMap.put("p.limit", commonSearchRequest.getLimit());
        predicateMap.put("p.offset", commonSearchRequest.getOffset());
        predicateMap.put("orderby", "@jcr:content/cq:lastReplicated");
        predicateMap.put("orderby.sort", "desc");
        predicateMap.putAll(damResultFetch(commonSearchRequest));
        predicateMap.put("1_group.1_group.p.or", "true");
        predicateMap.put("1_group.2_group.p.or", "true");
        predicateMap.put("1_group.p.or", "false");
        predicateMap.put("fulltext", commonSearchRequest.getSearchInput());
        LOGGER.info("Predicate Map {}", predicateMap.toString());
        return predicateMap;
    }

    protected Map damResultFetch(CommonSearchRequest commonSearchRequest)
    {
        Map predicateMap = new HashMap();
        if(commonSearchRequest.getSearchPath().contains("dam"))
        {
            predicateMap.put("type", "dam:Asset");
            int count = 1;
            String as[] = commonSearchRequest.getTags();
            int i = as.length;
            for(int k = 0; k < i; k++)
            {
                String tagId = as[k];
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid.property").toString(), "jcr:content/metadata/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid").toString(), tagId);
                count++;
            }

            int countForLocation = 1;
            String as2[] = commonSearchRequest.getLocationTags();
            int l = as2.length;
            for(int l1 = 0; l1 < l; l1++)
            {
                String locationTag = as2[l1];
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid.property").toString(), "jcr:content/metadata/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid").toString(), locationTag);
                countForLocation++;
            }

        } else
        {
            predicateMap.put("2_group.1_type", "cq:Page");
            predicateMap.put("2_group.2_type", "dam:Asset");
            predicateMap.put("2_group.p.or", "true");
            int count = 1;
            String as1[] = commonSearchRequest.getTags();
            int j = as1.length;
            for(int i1 = 0; i1 < j; i1++)
            {
                String tagId = as1[i1];
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid.property").toString(), "jcr:content/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid").toString(), tagId);
                count++;
            }

            as1 = commonSearchRequest.getTags();
            j = as1.length;
            for(int j1 = 0; j1 < j; j1++)
            {
                String tagId = as1[j1];
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid.property").toString(), "jcr:content/metadata/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.1_group.").append(count).append("_tagid").toString(), tagId);
                count++;
            }

            int countForLocation = 1;
            String as3[] = commonSearchRequest.getLocationTags();
            int k1 = as3.length;
            for(int i2 = 0; i2 < k1; i2++)
            {
                String locationTag = as3[i2];
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid.property").toString(), "jcr:content/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid").toString(), locationTag);
                countForLocation++;
            }

            as3 = commonSearchRequest.getLocationTags();
            k1 = as3.length;
            for(int j2 = 0; j2 < k1; j2++)
            {
                String locationTag = as3[j2];
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid.property").toString(), "jcr:content/metadata/cq:tags");
                predicateMap.put((new StringBuilder()).append("1_group.2_group.").append(countForLocation).append("_tagid").toString(), locationTag);
                countForLocation++;
            }

        }
        return predicateMap;
    }

    protected SearchResult executeQuery(Map predicateMap, Session session)
    {
        Query queryObj = queryBuilder.createQuery(PredicateGroup.create(predicateMap), session);
        return queryObj.getResult();
    }

    protected CommonSearchResultWrapper generateCountObjectFromResult(SearchResult querySearchResult, CommonSearchResultWrapper resultWrapper)
    {
        long totalMatches = querySearchResult.getTotalMatches();
        if(totalMatches == 1L)
            resultWrapper.setSingularResult("true");
        resultWrapper.setTotalMatches(totalMatches);
        resultWrapper.setHitsPerPage(querySearchResult.getHitsPerPage());
        resultWrapper.setHitsCount(querySearchResult.getHits().size());
        return resultWrapper;
    }

    protected CommonSearchResult generateResultObjectFromHit(Hit hit, SlingHttpServletRequest request)
        throws RepositoryException
    {
        return new CommonSearchResult(hit, request);
    }

    private List buildTagTreeAndChildren(Tag tag, Facet facetPages, Facet facetAssets, int level, TagManager tagManager, List searchTags)
    {
        if(tag != null)
        {
            int result[] = checkTagInFacets(tag, facetPages, facetAssets, tagManager);
            if(result[0] == 1)
            {
                searchTags.add(new SearchFilterTag(tag.getTagID(), tag.getTitle(), result[1], false, level));
                LOGGER.info("Tag added in the linkedList {}", tag.getTagID());
            }
            Tag childTag;
            for(Iterator children = tag.listChildren(); children.hasNext(); buildTagTreeAndChildren(childTag, facetPages, facetAssets, level + 1, tagManager, searchTags))
                childTag = (Tag)children.next();

        }
        return searchTags;
    }

    private int[] checkTagInFacets(Tag tag, Facet facetPages, Facet facetAssets, TagManager tagManager)
    {
        int flag;
        int tagCount;
label0:
        {
            flag = 0;
            tagCount = 0;
            Tag facetTag = null;
            if(facetPages == null)
                break label0;
            List list = facetPages.getBuckets();
            Iterator iterator = list.iterator();
            Bucket bucket;
            do
            {
                if(!iterator.hasNext())
                    break label0;
                bucket = (Bucket)iterator.next();
                facetTag = tagManager.resolve(bucket.getValue());
            } while(!tag.getTagID().equalsIgnoreCase(facetTag.getTagID()));
            tagCount = (int)bucket.getCount();
            flag = 1;
        }
label1:
        {
            if(facetAssets == null)
                break label1;
            List listAssetBuckets = facetAssets.getBuckets();
            Iterator iterator1 = listAssetBuckets.iterator();
            Bucket bucketAssetTag;
            Tag facetAssetTag;
            do
            {
                if(!iterator1.hasNext())
                    break label1;
                bucketAssetTag = (Bucket)iterator1.next();
                facetAssetTag = tagManager.resolve(bucketAssetTag.getValue());
            } while(!tag.getTagID().equalsIgnoreCase(facetAssetTag.getTagID()));
            tagCount += (int)bucketAssetTag.getCount();
            flag = 1;
        }
        return (new int[] {
            flag, tagCount
        });
    }

    protected void bindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        queryBuilder = paramQueryBuilder;
    }

    protected void unbindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        if(queryBuilder == paramQueryBuilder)
            queryBuilder = null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/search/impl/SearchServiceImpl);
    private transient QueryBuilder queryBuilder;
    private static final int CONSTANT_ZERO = 0;
    private static final int CONSTANT_ONE = 1;

}
