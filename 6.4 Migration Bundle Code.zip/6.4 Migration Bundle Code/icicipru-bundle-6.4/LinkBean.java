// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LinkBean.java

package com.icicipru.sightly.bean;


public class LinkBean
{

    public LinkBean()
    {
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String link)
    {
        this.link = link;
    }

    public String getNrOfCols()
    {
        return nrOfCols;
    }

    public void setNrOfCols(String nrOfCols)
    {
        this.nrOfCols = nrOfCols;
    }

    public String getCssClass()
    {
        return cssClass;
    }

    public void setCssClass(String cssClass)
    {
        this.cssClass = cssClass;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getActive()
    {
        return active;
    }

    public void setActive(String active)
    {
        this.active = active;
    }

    public String getForDesktop()
    {
        return forDesktop;
    }

    public void setForDesktop(String forDesktop)
    {
        this.forDesktop = forDesktop;
    }

    public String getForMobile()
    {
        return forMobile;
    }

    public void setForMobile(String forMobile)
    {
        this.forMobile = forMobile;
    }

    private String title;
    private String link;
    private String nrOfCols;
    private String cssClass;
    private String id;
    private String active;
    private String forDesktop;
    private String forMobile;
}
