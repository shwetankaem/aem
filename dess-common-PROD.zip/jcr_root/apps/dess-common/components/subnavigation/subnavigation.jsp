<%--
  Sub-Navigation  component
  Draws the Sub-Navigation

--%>
<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page trimDirectiveWhitespaces="true" %>
<%@page import="com.dess.cq.common.models.SubNavigation,com.dess.cq.common.models.Link,java.util.LinkedList,java.util.List" %>

<% 		
    	Session session = resource.getResourceResolver().adaptTo(Session.class);
    	String rootPath = properties.get("rootPath","");
    	String level = properties.get("level","5");
    
		if((String)request.getAttribute("rootPath")!=null) {
			rootPath = (String)request.getAttribute("rootPath");
		}
		
		if((String)request.getAttribute("level")!=null) {
			level = (String)request.getAttribute("level");
		}
		
		if(level.equalsIgnoreCase("")) {
            level = "5";
		}
		
		int levelToBeShown = Integer.parseInt(level);
      	Page rootPage =  pageManager.getContainingPage(rootPath);
		if(rootPage == null )  rootPage = currentPage ; 
		SubNavigation sub_nav = new SubNavigation(rootPage,levelToBeShown);
		List<Link> links = sub_nav.getLinks();
%>
<c:set var="position" value="<%= properties.get("position",false) %>" />
			<c:choose>
               <c:when test="${position eq 'false'}">
                  <div class="sub-nav-container hidden-md hidden-lg">
                  <button type="button" class="btn btn-secondary btn-block icon-right icon-lg collapsed" data-toggle="collapse" data-target="#jsSubNav">
              		Section menu
              		<%-- TODO - Show/hidden icons below based on menu open/closed --%>
              	  <span class="icon icon-arrow-down"></span>
              <span class="icon icon-arrow-up"></span>
            </button>  
               </c:when>
               <c:otherwise>
               <div class="sub-nav-container hidden-xs hidden-sm">
               </c:otherwise>
            </c:choose>

   <c:set var="subnavList" value="<%=links %>" />
   <c:set var="previousLevel" value="0" />
   <c:set var="activeClass" value="" />
   <c:set var="currentPagePath" value="<%= currentPage.getPath() %>" />
   <c:forEach  items="${subnavList}" var="linkItem">
      <c:choose>
         <c:when test="${linkItem.level > previousLevel}">
            <c:choose>
                <c:when test="${linkItem.level ==1 && position eq 'false'}">
                  <ul id="jsSubNav" class="list-links sub-nav collapse">
               </c:when>
               <c:when test="${linkItem.level ==1}">
                  <ul class="list-links sub-nav">
               </c:when>
               <c:otherwise>
               <ul>
               </c:otherwise>
            </c:choose>
         </c:when>
         <c:when test="${linkItem.level < previousLevel}">
         <c:forEach begin="${linkItem.level}" end="${previousLevel -1 }" >
         </ul>
         </c:forEach>
         </c:when>
      </c:choose>
      <c:choose>
       <c:when test="${currentPagePath eq linkItem.path && linkItem.level==2}">
      <c:set var="activeClass" value="active-parent active" />
      <c:set var="active" value="1"/>
      </c:when>
      <c:when test="${currentPagePath eq linkItem.path && linkItem.level !=2}">
      <c:set var="activeClass" value="active" />
      <c:set var="active" value="1"/>
      </c:when>
      <c:when test="${fn:contains(currentPagePath, linkItem.path) && linkItem.level > 1}">
   		<c:set var="activeClass" value="active-parent" />
   		 <c:set var="active" value="0"/>
	  </c:when>
      <c:otherwise>
       <c:set var="activeClass" value="" />
       <c:set var="active" value="0"/>
      </c:otherwise>
      </c:choose>
      <li class="${activeClass}"><a href="${linkItem.path}.html">${linkItem.title}
      <c:choose>
      <c:when test="${active == 1}">
      <span class="sr-only"> - you are here</span></a>
      </c:when>
      <c:otherwise>
      </a>
      </c:otherwise>
      </c:choose>
      <c:set var="previousLevel" value="${linkItem.level}" />
   </c:forEach>
   <c:forEach begin="0" end="${previousLevel}">
   </ul></li>
   </c:forEach>
</div>