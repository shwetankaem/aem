(function() {
    var originaltransferConfigToCell = CUI.rte.commands.Table.prototype.transferConfigToCell;
    CQ.Ext.override(CUI.rte.commands.Table,{
		transferConfigToCell: function(context, dom, config) {
        var com = CUI.rte.Common;
            if(com.getParentWindowRef(context)? com.getParentWindowRef(context).hasAttribute("configuredforcommon"):""){


        var noneConfig = CUI.rte.commands.Table.CONFIG_NONE;
        if (config.cellType && (config.cellType != noneConfig)) {
            if (!com.isTag(dom, config.cellType)) {
                var changedDom = context.createElement(config.cellType);
                com.copyAttributes(dom, changedDom);
                com.replaceNode(dom, changedDom);
                dom = changedDom;
            }
        }
		com.removeAttribute(dom, "class");

        if (config.align) {
            if (config.align != noneConfig && config.align!='left') {
                com.addClass(dom, "text-"+config.align);
            }
        }

            if (config.valign) {
            if (config.valign != noneConfig && config.valign!='middle') {
                 com.addClass(dom, "text-"+config.valign);
            }
        }

        if (config.cellStyle && (config.cellStyle != noneConfig)) {
            com.addClass(dom, config.cellStyle);
        }
        }else{
		originaltransferConfigToCell.apply(this,[context, dom, config]);
        }


        }
    } );
}());