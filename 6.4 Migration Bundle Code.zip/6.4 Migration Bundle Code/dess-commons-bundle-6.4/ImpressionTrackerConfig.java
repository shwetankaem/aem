// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImpressionTrackerConfig.java

package com.dess.cq.common.config;

import java.util.List;

public interface ImpressionTrackerConfig
{

    public abstract List getListOfPublishUrls();
}
