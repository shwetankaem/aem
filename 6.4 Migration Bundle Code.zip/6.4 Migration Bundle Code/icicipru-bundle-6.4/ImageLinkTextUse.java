// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImageLinkTextUse.java

package com.icicipru.sightly.use;

import com.adobe.cq.sightly.WCMUsePojo;
import com.icicipru.sightly.bean.ImageLinkText;
import java.util.ArrayList;
import java.util.List;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageLinkTextUse extends WCMUsePojo
{

    public ImageLinkTextUse()
    {
        links = new ArrayList();
    }

    public String[] getStringArray()
    {
        return stringArray;
    }

    public void setStringArray(String stringArray[])
    {
        this.stringArray = stringArray;
    }

    public List getLinks()
    {
        return links;
    }

    public void setLinks(List links)
    {
        this.links = links;
    }

    public void activate()
        throws Exception
    {
        LOGGER.info("ImageLinkText STARTS");
        stringArray = (String[])(String[])getProperties().get("imageLinkText", new String[0]);
        if(getStringArray().length > 0)
        {
            LOGGER.debug((new StringBuilder()).append("stringArray length found to be:").append(getStringArray().length).toString());
            try
            {
                String as[] = getStringArray();
                int i = as.length;
                for(int j = 0; j < i; j++)
                {
                    String Obj = as[j];
                    JSONObject jsonObject = new JSONObject(Obj);
                    ImageLinkText img = new ImageLinkText();
                    img.setText(jsonObject.getString("text"));
                    img.setSubText(jsonObject.getString("subText"));
                    img.setImgPath(jsonObject.getString("imgPath"));
                    img.setLinkPath(jsonObject.getString("linkPath"));
                    img.setImgAlt(jsonObject.getString("imgAlt"));
                    links.add(img);
                }

            }
            catch(JSONException je)
            {
                LOGGER.error("JSONException:", je);
                LOGGER.info("JSONException:", je);
            }
            catch(Exception e)
            {
                LOGGER.error("Exception:", e);
                LOGGER.info("Exception:", e);
            }
        } else
        {
            LOGGER.debug("stringArray length found to be empty");
        }
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/icicipru/sightly/use/ImageLinkTextUse);
    private String stringArray[];
    private List links;

}
