// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConfiguredListServiceImpl.java

package com.dess.cq.common.helper.impl;

import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.dess.cq.common.helper.ConfiguredListService;
import com.dess.cq.common.helper.PopularListService;
import com.dess.cq.common.search.impl.SearchServiceImpl;
import com.dess.cq.common.search.models.CommonSearchRequest;
import com.dess.cq.common.search.models.CommonSearchResultWrapper;
import java.util.*;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfiguredListServiceImpl extends SearchServiceImpl
    implements ConfiguredListService
{

    public ConfiguredListServiceImpl()
    {
    }

    public SearchResult getResults(Map queryMap, Session session)
    {
        return executeQuery(queryMap, session);
    }

    private Map createQueryMap(String connectTo, String limit, SlingHttpServletRequest request)
    {
        PageManager pageManager = (PageManager)request.getResourceResolver().adaptTo(com/day/cq/wcm/api/PageManager);
        Map queryMap = new HashMap();
        Tag tagsArry[] = pageManager.getContainingPage(connectTo).getTags();
        if(null != tagsArry && tagsArry.length > 0)
        {
            queryMap.putAll(createQueryMap());
            int iCountForTags = 1;
            queryMap.put("path", connectTo);
            queryMap.put("property", "jcr:content/cq:tags");
            queryMap.put("property.or", "true");
            queryMap.put("p.limit", limit);
            Tag atag[] = tagsArry;
            int i = atag.length;
            for(int j = 0; j < i; j++)
            {
                Tag tagString = atag[j];
                String tagId = tagString.getTagID();
                queryMap.put((new StringBuilder()).append("property.").append(iCountForTags).append("_value").toString(), tagId);
                iCountForTags++;
            }

        }
        return queryMap;
    }

    private Map createQueryMap(CommonSearchRequest commonSearchRequest)
    {
        Map queryMap = new HashMap();
        queryMap.putAll(createQueryMap());
        queryMap.put("path", commonSearchRequest.getSearchPath());
        if(null != commonSearchRequest.getTagSearchArray() && commonSearchRequest.getTagSearchArray().length > 0)
        {
            int iCountForTags = 1;
            queryMap.put("property", "jcr:content/cq:tags");
            queryMap.put("property.or", "true");
            String as[] = commonSearchRequest.getTagSearchArray();
            int i = as.length;
            for(int j = 0; j < i; j++)
            {
                String tagId = as[j];
                queryMap.put((new StringBuilder()).append("property.").append(iCountForTags).append("_value").toString(), tagId);
                iCountForTags++;
            }

        }
        queryMap.put("p.limit", commonSearchRequest.getLimit());
        queryMap.put("p.offset", commonSearchRequest.getOffset());
        queryMap.put("fulltext", commonSearchRequest.getSearchInput());
        queryMap.putAll(damResultFetch(commonSearchRequest));
        return queryMap;
    }

    private Map createQueryMap()
    {
        Map queryMap = new HashMap();
        queryMap.put("orderby", "@jcr:content/cq:lastReplicated");
        queryMap.put("orderby.index", "true");
        queryMap.put("orderby.sort", "desc");
        return queryMap;
    }

    public CommonSearchResultWrapper getConfiguredListResult(CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        Session session = (Session)commonSearchRequest.getRequest().getResourceResolver().adaptTo(javax/jcr/Session);
        CommonSearchResultWrapper resultsWrapper = new CommonSearchResultWrapper();
        Map queryMap = new HashMap();
        String limit = commonSearchRequest.getLimit();
        String connectTo = commonSearchRequest.getSearchPath();
        String listType = commonSearchRequest.getListType();
        if(commonSearchRequest.getTags() == null)
            commonSearchRequest.setTags(getDefaultStringArray());
        if(commonSearchRequest.getLocationTags() == null)
            commonSearchRequest.setLocationTags(getDefaultStringArray());
        if(listType != null && listType.equalsIgnoreCase("relatedList"))
            queryMap = createQueryMap(connectTo, limit, commonSearchRequest.getRequest());
        else
        if(listType != null && listType.equalsIgnoreCase("latestList"))
            queryMap = createQueryMap(commonSearchRequest);
        else
            resultsWrapper = getPopularResults(commonSearchRequest);
        if(listType != null && !listType.equalsIgnoreCase("popularList"))
        {
            SearchResult result = getResults(queryMap, session);
            resultsWrapper = getConfiguredListResultObject(commonSearchRequest, result);
        }
        return resultsWrapper;
    }

    private CommonSearchResultWrapper getConfiguredListResultObject(CommonSearchRequest commonSearchRequest, SearchResult result)
        throws RepositoryException
    {
        CommonSearchResultWrapper wrapper = new CommonSearchResultWrapper();
        if(result.getHits() != null && !result.getHits().isEmpty())
        {
            wrapper = generateCountObjectFromResult(result, wrapper);
            wrapper = generatePaginationFromResult(result, commonSearchRequest, wrapper);
            List resultObjectList = new ArrayList();
            Hit hit;
            for(Iterator iterator = result.getHits().iterator(); iterator.hasNext(); resultObjectList.add(generateResultObjectFromHit(hit, commonSearchRequest.getRequest())))
                hit = (Hit)iterator.next();

            wrapper.setResults(resultObjectList);
        }
        return wrapper;
    }

    private CommonSearchResultWrapper getPopularResults(CommonSearchRequest commonSearchRequest)
    {
        PageManager pageManager = (PageManager)commonSearchRequest.getRequest().getResourceResolver().adaptTo(com/day/cq/wcm/api/PageManager);
        CommonSearchResultWrapper wrapper = new CommonSearchResultWrapper();
        Page targetPage = pageManager.getPage(commonSearchRequest.getSearchPath());
        try
        {
            wrapper = mostPopularPages.getMostPopularResult(commonSearchRequest, targetPage);
        }
        catch(Exception e)
        {
            LOGGER.error("Error in getPopularResults {} ", e.getMessage());
        }
        return wrapper;
    }

    protected void bindMostPopularPages(PopularListService paramPopularListService)
    {
        mostPopularPages = paramPopularListService;
    }

    protected void unbindMostPopularPages(PopularListService paramPopularListService)
    {
        if(mostPopularPages == paramPopularListService)
            mostPopularPages = null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/helper/impl/ConfiguredListServiceImpl);
    private static final String RELATED_LIST = "relatedList";
    private static final String LATEST_LIST = "latestList";
    private static final String POPULAR_LIST = "popularList";
    private static final int CONSTANT_ZERO = 0;
    private transient PopularListService mostPopularPages;

}
