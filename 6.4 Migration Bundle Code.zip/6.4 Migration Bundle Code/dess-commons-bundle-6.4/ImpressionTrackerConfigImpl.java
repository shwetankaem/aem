// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImpressionTrackerConfigImpl.java

package com.dess.cq.common.config.impl;

import com.dess.cq.common.config.ImpressionTrackerConfig;
import java.util.*;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.BundleContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImpressionTrackerConfigImpl
    implements ImpressionTrackerConfig
{

    public ImpressionTrackerConfigImpl()
    {
    }

    public List getListOfPublishUrls()
    {
        return publishUrls;
    }

    void activate(BundleContext bundleContext, Map props)
    {
        publishUrls = Arrays.asList(PropertiesUtil.toStringArray(props.get("listOfPublishUrls"), new String[0]));
        LOGGER.info("list of publish Urls {} ", publishUrls);
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/config/impl/ImpressionTrackerConfigImpl);
    private List publishUrls;
    public static final String PROP_RESOURCE_TYPES = "listOfPublishUrls";

}
