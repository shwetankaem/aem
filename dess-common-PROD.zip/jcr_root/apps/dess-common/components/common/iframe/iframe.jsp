<%--

  iFrame component.
 
--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%><%
%><%@page session="false" %>


<c:if test="${wcmEditMode}">
	<cq:includeClientLib categories="author.dess.common.components.iframe"/>
</c:if>

<c:if test="${properties.iframeactivateid}">
	<c:set var="idiframe" value="id=\"${properties.iframeid}\""/>
</c:if>

<c:set var="iframeUrl" value="src=\"${properties.iframeurl}\""/>

<c:set var="ifclasses" value="class=\"${properties.ifshowonprint eq 'true' ? '' :'hidden-print'} ${empty properties.ifclassappend ? '' :properties.ifclassappend}\""/> 

<c:if test="${not empty properties.iframeurl}">
    <dess:cleanHTMLFragment>
        <iframe ${idiframe} ${iframeUrl} ${ifclasses} width="100%" frameborder="0" scrolling="no" style="overflow: hidden; height: 281px;"></iframe>
    </dess:cleanHTMLFragment>
</c:if>


	
