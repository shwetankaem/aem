<%--

  Freedom component.

--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%>
<%
%><%@page session="false" %>


<c:if test="${wcmEditMode}">
<cq:includeClientLib categories="author.dess.common.components.freedom"/>
</c:if>
<div class="freedom">
<c:if test="${not empty properties.htmltoinsert}">
	${properties.htmltoinsert}
</c:if> 
</div>    
