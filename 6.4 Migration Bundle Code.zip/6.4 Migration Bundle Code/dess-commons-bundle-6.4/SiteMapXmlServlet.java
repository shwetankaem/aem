// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SiteMapXmlServlet.java

package com.dess.cq.common.servlets;

import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.xml.stream.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SiteMapXmlServlet extends SlingSafeMethodsServlet
{

    public SiteMapXmlServlet()
    {
    }

    protected void activate(Map properties)
    {
        externalizerDomainArray = PropertiesUtil.toStringArray(properties.get("externalizer.domain.map"));
    }

    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
        throws ServletException, IOException
    {
        response.setContentType(request.getResponseContentType());
        ResourceResolver resourceResolver = request.getResourceResolver();
        PageManager pageManager = (PageManager)resourceResolver.adaptTo(com/day/cq/wcm/api/PageManager);
        Page page = pageManager.getContainingPage(request.getResource());
        getExternalizerDomain(page);
        LOGGER.info("externalizer Domain {} ", externalizerDomain);
        XMLOutputFactory outputFactory = XMLOutputFactory.newFactory();
        try
        {
            XMLStreamWriter stream = outputFactory.createXMLStreamWriter(response.getWriter());
            stream.writeStartDocument("1.0");
            stream.writeStartElement("", "urlset", "http://www.sitemaps.org/schemas/sitemap/0.9");
            stream.writeNamespace("", "http://www.sitemaps.org/schemas/sitemap/0.9");
            int ilevel = 0;
            write(page, stream, resourceResolver, ilevel);
            for(Iterator children = page.listChildren(new PageFilter(), true); children.hasNext(); write((Page)children.next(), stream, resourceResolver, ilevel + 1));
            stream.writeEndElement();
            stream.writeEndDocument();
        }
        catch(XMLStreamException e)
        {
            throw new IOException(e);
        }
    }

    private void getExternalizerDomain(Page requestedPage)
    {
        String domainKeyValue = "";
        String keyValueArray[] = new String[1];
        if(externalizerDomainArray != null)
        {
            int count = 0;
            do
            {
                if(count >= externalizerDomainArray.length)
                    break;
                domainKeyValue = externalizerDomainArray[count];
                if(domainKeyValue != null && !domainKeyValue.equalsIgnoreCase("") && domainKeyValue.contains(":"))
                    keyValueArray = domainKeyValue.split(":");
                if(keyValueArray[0] != null && keyValueArray[0].equalsIgnoreCase(requestedPage.getPath()))
                {
                    externalizerDomain = keyValueArray[1];
                    break;
                }
                count++;
            } while(true);
        } else
        {
            externalizerDomain = "publish";
        }
    }

    private void write(Page page, XMLStreamWriter stream, ResourceResolver resolver, int level)
        throws XMLStreamException
    {
        stream.writeStartElement("http://www.sitemaps.org/schemas/sitemap/0.9", "url");
        stream.writeStartElement("http://www.sitemaps.org/schemas/sitemap/0.9", "loc");
        String pagePath = "";
        if(level == 0)
            pagePath = (new StringBuilder()).append(page.getPath()).append("/index").toString();
        else
            pagePath = page.getPath();
        String loc = externalizer.externalLink(resolver, externalizerDomain, String.format("%s.html", new Object[] {
            pagePath
        }));
        stream.writeCharacters(loc);
        stream.writeEndElement();
        Calendar lastModified = page.getLastModified();
        String changefreq = (String)page.getProperties().get("changefreq", null);
        String priority = (String)page.getProperties().get("priority", null);
        if(lastModified != null)
        {
            java.util.Date date = lastModified.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            stream.writeStartElement("http://www.sitemaps.org/schemas/sitemap/0.9", "lastmod");
            stream.writeCharacters(sdf.format(date));
            stream.writeEndElement();
        }
        if(priority != null && !priority.equals(""))
        {
            stream.writeStartElement("http://www.sitemaps.org/schemas/sitemap/0.9", "changefreq");
            stream.writeCharacters(changefreq);
            stream.writeEndElement();
        }
        if(priority != null && !priority.equals(""))
        {
            stream.writeStartElement("http://www.sitemaps.org/schemas/sitemap/0.9", "priority");
            stream.writeCharacters(priority);
            stream.writeEndElement();
        }
        stream.writeEndElement();
    }

    protected void bindExternalizer(Externalizer paramExternalizer)
    {
        externalizer = paramExternalizer;
    }

    protected void unbindExternalizer(Externalizer paramExternalizer)
    {
        if(externalizer == paramExternalizer)
            externalizer = null;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/servlets/SiteMapXmlServlet);
    private static final String PROP_EXTERNALIZER_DOMAIN_MAP = "externalizer.domain.map";
    private static final String NS = "http://www.sitemaps.org/schemas/sitemap/0.9";
    private static final String CONSTANT_INDEX = "/index";
    private static final String CONSTANT_PUBLISH = "publish";
    private Externalizer externalizer;
    private String externalizerDomainArray[];
    private String externalizerDomain;

}
