// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SubNavigationServiceImpl.java

package com.dess.cq.common.helper.impl;

import com.day.cq.search.*;
import com.day.cq.search.result.SearchResult;
import com.dess.cq.common.helper.SubNavigationService;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Session;

public class SubNavigationServiceImpl
    implements SubNavigationService
{

    public SubNavigationServiceImpl()
    {
    }

    public SearchResult getResults(Map map, Session session)
    {
        return createQuery(map, session).getResult();
    }

    private Query createQuery(Map map, Session session)
    {
        return queryBuilder.createQuery(PredicateGroup.create(map), session);
    }

    private Map createMapForComponentSearch(String currentPagePath)
    {
        Map map = new HashMap();
        map.put("path", (new StringBuilder()).append(currentPagePath).append("/").append("jcr:content").toString());
        map.put("type", "nt:unstructured");
        map.put("property", "sling:resourceType");
        map.put("property.value", "paw/components/content/commons/subnavigation");
        return map;
    }

    public SearchResult getResultsComponentSearch(String currentPagePath, Session session)
    {
        Map map = createMapForComponentSearch(currentPagePath);
        return getResults(map, session);
    }

    protected void bindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        queryBuilder = paramQueryBuilder;
    }

    protected void unbindQueryBuilder(QueryBuilder paramQueryBuilder)
    {
        if(queryBuilder == paramQueryBuilder)
            queryBuilder = null;
    }

    private QueryBuilder queryBuilder;
}
