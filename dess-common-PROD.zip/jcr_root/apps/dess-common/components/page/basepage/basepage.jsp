<%--
    
    Base Page  component.
    
    Base Page component to create a common structure
    
    --%>
<%@include file="/apps/dess-common/components/global.jsp"%>

<!DOCTYPE html>
<!--[if IE]><![endif]-->
<!--[if lt IE 7 ]> <html lang="en" class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> 
<html lang="en" class=""> 
<!--<![endif]-->
<html lang="en">

    <dess:cleanHTMLFragment>
	    <head> 
            <cq:include script="headlibs.jsp"/>
        </head>
        <body>
            <cq:include script="body.jsp"/>
        </body>
	</dess:cleanHTMLFragment>
</html>
