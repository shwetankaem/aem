<%--

  Video component.

--%><%
%><%@include file="/apps/dess-common/components/global.jsp"%><%
%><%@page session="false" trimDirectiveWhitespaces="false"%>

<c:if test="${properties.activateid}">
<c:set var="videoId" value="id=\"${properties.videoId}\""/>
</c:if>

<c:choose>
<c:when test="${fn:contains(properties.videoURL, 'vimeo')}">
	<c:set var="divClass" value="embed-responsive embed-responsive-16by9-vimeo"/>
</c:when>
<c:otherwise>
    <c:set var="divClass" value="embed-responsive embed-responsive-16by9"/>
</c:otherwise>
</c:choose>

<c:choose>
<c:when test="${fn:length(properties.videoURL) > 0}">
    <dess:cleanHTMLFragment>	
    <div class="video ${empty properties.classappend ? '' : properties.classappend} ${properties.videoshowonprint eq 'true'?'':'hidden-print'}" ${videoId} >
	</dess:cleanHTMLFragment>
        <span class=" sr-only ">The following video is about ${properties.videoTitle} and has a transcript (see below).</span>
        <div class="${divClass}">
                  <iframe class="embed-responsive-item" src="${properties.videoURL}"></iframe>
              </div>
        <c:if test="${fn:length(properties.transriptURL) > 0}">
        <a href="${properties.transriptURL}.html" class="transcript">View video transcript<span class="sr-only"> about ${properties.videoTitle}</span></a>
        </c:if >
            </div>
</c:when>
<c:otherwise>
    <h4>Edit Video ( Providing the Video url is mandatory) </h4>
</c:otherwise>
</c:choose>