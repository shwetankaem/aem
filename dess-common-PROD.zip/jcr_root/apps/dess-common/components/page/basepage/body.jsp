<%@page session="false"%>
<%@include file="/apps/dess-common/components/global.jsp"%>

<cq:include script="header.jsp"/>
<cq:include script="content.jsp"/>
<cq:include script="footer.jsp"/>