// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImageLinkText.java

package com.icicipru.sightly.bean;


public class ImageLinkText
{

    public ImageLinkText()
    {
    }

    public String getText()
    {
        return text;
    }

    public void setText(String text)
    {
        this.text = text;
    }

    public String getSubText()
    {
        return subText;
    }

    public void setSubText(String subText)
    {
        this.subText = subText;
    }

    public String getImgPath()
    {
        return imgPath;
    }

    public void setImgPath(String imgPath)
    {
        this.imgPath = imgPath;
    }

    public String getImgAlt()
    {
        return imgAlt;
    }

    public void setImgAlt(String imgAlt)
    {
        this.imgAlt = imgAlt;
    }

    public String getLinkPath()
    {
        return linkPath;
    }

    public void setLinkPath(String linkPath)
    {
        this.linkPath = linkPath;
    }

    private String text;
    private String subText;
    private String imgPath;
    private String linkPath;
    private String imgAlt;
}
