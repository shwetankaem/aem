// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonUtility.java

package com.dess.cq.common.utilities;

import java.util.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CommonUtility
{

    public CommonUtility()
    {
    }

    public static Map jsonStringToMap(String json)
    {
        Map outMap = new HashMap();
        try
        {
            JSONObject jsonData = new JSONObject(json);
            Iterator nameItr = jsonData.keys();
            do
            {
                if(!nameItr.hasNext())
                    break;
                String key = (String)nameItr.next();
                if(!StringUtils.isBlank(key))
                    outMap.put(key, jsonData.getString(key));
            } while(true);
        }
        catch(JSONException jsonException)
        {
            LOGGER.error("Exception while converting JSON String to Map : {}", jsonException.getMessage());
        }
        return outMap;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/utilities/CommonUtility);

}
