$.fn.search = function () {
    var searchInput = $.fn.getQueryVariable("searchInput");
    var selectArea = $.fn.getQueryVariable("selectArea");
    var limit = $("#searchHeader").attr("data-pagination");
    if(typeof limit === "undefined" || limit =="") {
        limit = 25;
    }
    var urll = document.URL;

    var urlWithoutparameters = urll.substring(0,urll.indexOf("?"));

    urlWithoutparameters = urlWithoutparameters.substring(0, urlWithoutparameters.length - 5);
    if (searchInput && selectArea && limit && urlWithoutparameters && $("#search-results-template").html()!=undefined) {
        var headerSource   = $("#search-header-template").html();
        var headerTemplate = Handlebars.compile(headerSource);
        var resultsSource   = $("#search-results-template").html();
        var resultsTemplate = Handlebars.compile(resultsSource);
        var url =  urlWithoutparameters + ".search.html?searchInput=" + searchInput;
        url = url + "&selectArea=" + selectArea;
        url = url + "&limit=" + limit;
        var newsectionId = [];

        if(sessionStorage.getItem("locationChecked") == "true" || sessionStorage.getItem("treeChecked") == "true") {
            for (var i = 0; i < sessionStorage.length; i++){
                var checkid = sessionStorage.getItem(sessionStorage.key(i));
                $('#'+checkid).prop('checked', true);
            }
        }
        $('#jsLocations input:checkbox').each(function() {
            var $this = $(this);
            if($this.is(":checked")){
                var checkid = $this.attr("data-tagid");
                var locationParams= "&locationTag=" +checkid;
                newsectionId.push(locationParams);;
            }
        });

        $('#jsTree input:checkbox').each(function() {
            var $this = $(this);
            if($this.is(":checked")){
                var checkid = $this.attr("data-tagid");
                var sectionParams= "&sectionTag=" +checkid;
                newsectionId.push(sectionParams);
            }
        });
        if(newsectionId.length == 0){
            var offsetStorage = sessionStorage.getItem("offset");
            if(offsetStorage !== null) {
                url = url+"&offset="+offsetStorage;
             }
            $.ajax({
                url: url,
                type: "get",
                dataType: "json",
                success: function (result) {

                    if(result!=null && result!= "{}") {
                        $("#searchHeader").html(headerTemplate(result));
                        $("#search-Results").html(resultsTemplate(result));
                    }
                }
            });
        }
        if(newsectionId.length > 0){
            var sectionst = newsectionId.toString();
            var replacedSectio = sectionst.replace(/,/g, "");
            var urlchec = url + replacedSectio;
            var offsetStorage = sessionStorage.getItem("offset");
            if(offsetStorage !== null) {
                urlchec = urlchec+"&offset="+offsetStorage;
            }
            $.ajax({
                url: urlchec,
                type: "get",
                dataType: "json",
                success: function (resultt) {
                    if(resultt!=null && resultt!= "{}") {
                        $("#searchHeader").html(headerTemplate(resultt));
                        $("#search-Results").html(resultsTemplate(resultt));
                    }
                }
            });
        }
       $("#search-Results").on("click", ".pager li.next a" , function(e) {
            e.preventDefault();
            var nextAjaxURL = $(this).attr('href');
            sessionStorage && sessionStorage.setItem("offset",$.fn.getURLParameter(nextAjaxURL,"offset"));
            $.ajax({
                url: nextAjaxURL,
                type: "get",
                dataType: "json",
                success: function (data) {
                    if(data!=null) {
                        $("#searchHeader").html(headerTemplate(data));
                        $("#search-Results").html(resultsTemplate(data));
                    }
                }
            });  
        });

        $("#search-Results").on("click", ".pager li.previous a",function(e) {
            e.preventDefault();
            var previousAjaxUrl = $(this).attr('href');
            sessionStorage && sessionStorage.setItem("offset",$.fn.getURLParameter(previousAjaxUrl,"offset"));
            $.ajax({
                url: previousAjaxUrl,
                type: "get",
                dataType: "json",
                success: function (data) {
                    if(data!=null) {
                        $("#search-Results").html(resultsTemplate(data));
                    }
                }
            });
        });

        $.extend($.expr[':'], {
            unchecked: function (obj) {
                    return ((obj.type == 'checkbox' || obj.type == 'radio') && !$(obj).is(':checked'));
            }
        });
            
        $(".checktree-root input:checkbox").change(function() {
            sessionStorage.removeItem("offset");
            $(this).parent().next('ul').find('input:checkbox').prop('checked', $(this).prop("checked"));
            for (var i = $('.checktree-root').find('ul').length - 1; i >= 0; i--) {        
                $('.checktree-root').find('ul:eq(' + i + ')').prev('div').find(' input:checkbox').prop('checked', function () {        
                    return $(this).parent().next('ul').find('input:unchecked').length === 0 ? true : false;
                });
            }
            var sectionId = [];
            $("#jsTree input:checkbox").each(function(){
                var $this = $(this);
                if($this.is(":checked")){

                  sessionStorage && sessionStorage.setItem(this.id,this.id);

                  var checkid = $this.attr("data-tagid");
                  var sectionParams= "&sectionTag=" +checkid;
                   sectionId.push(sectionParams);
                } else {
                    sessionStorage && sessionStorage.removeItem(this.id);
                }
            });

            $("#jsLocations input:checkbox").each(function(){
                var $this = $(this);
                if($this.is(":checked")){
                    sessionStorage && sessionStorage.setItem(this.id,this.id);
                    var checkid = $this.attr("data-tagid");
                    var locationParams= "&locationTag=" +checkid;
                    sectionId.push(locationParams);
                } else {
                    sessionStorage && sessionStorage.removeItem(this.id);

                }
            });

            if ($("#jsTree input:checkbox:checked").length > 0){
                sessionStorage && sessionStorage.setItem("treeChecked","true");
            } else {
                sessionStorage && sessionStorage.removeItem("treeChecked");
            }
            if ($("#jsLocations input:checkbox:checked").length > 0){
                sessionStorage && sessionStorage.setItem("locationChecked","true");
            } else {
                sessionStorage && sessionStorage.removeItem("locationChecked");
            }
            var sectionstr = sectionId.toString();
            var replacedSection = sectionstr.replace(/,/g, "");
            urlcheck = url + replacedSection;
            $.ajax({
                url: urlcheck,
                type: "get",
                dataType: "json",
                success: function (data) {
                    if(data!=null && JSON.stringify(data)!="{}") {
                        $("#searchHeader").html(headerTemplate(data));
                        $("#search-Results").html(resultsTemplate(data));
                    }else{
                        $("#searchHeader").html("<div id=\"jsResultsHeader\" class=\"col-sm-12 col-md-12 col-lg-12\"><h2><span class=\"sr-only\">Your search has returned </span>0 Result</h2><hr class=\"hr-light-gray\"><cq:include path=\"search-parsys\" resourceType=\"foundation/components/parsys\" /></div>");
                        $("#search-Results").html("");

                    }
                    
                }
            });
        });
    }
};

$( document ).ready(function() {
    $.fn.search();
    $("#searchButton").on("click",function(e) {
       
        e.preventDefault();
        if($("#searchInput").val()=="") {
            $("#searchInput").attr("aria-invalid" , "true");
            $("#jsSearchBar .form-group").addClass("has-error");
            $("#error-div").attr("aria-hidden" , "false");
            $("#error-div").removeClass("hidden").addClass("has-error");
        } else {
            sessionStorage.removeItem("offsetStorage");
            $("#jsSearchBar").submit();
            sessionStorage.clear();
        }
    });
     $("#config-results-template").exists(function() {
    var resultsSource = $("#config-results-template").html();
	var resultsTemplate = Handlebars.compile(resultsSource);

	if (resultArrayJSON != null && resultArrayJSON != "") {
		$("#configResults").html(resultsTemplate(resultArrayJSON));
	}

	$("#searchButtonForConfigList").on("click",function(e) {
	        e.preventDefault();
	        if($("#searchInputForConfigList").val()=="") {
	            $("#searchInputForConfigList").attr("aria-invalid" , "true");
	            $("#jsSearchBarForConfigList .form-group").addClass("has-error");
	            $("#error-div-config-list").attr("aria-hidden" , "false");
	            $("#error-div-config-list").removeClass("hidden").addClass("has-error");
	        } else {
	            sessionStorage.removeItem("offsetStorage");
	            $("#jsSearchBarForConfigList").submit();
	            sessionStorage.clear();
	        }
	    });
     });
});
