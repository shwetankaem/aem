// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SubNavigation.java

package com.dess.cq.common.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;
import java.util.*;

// Referenced classes of package com.dess.cq.common.models:
//            Link

public class SubNavigation
{

    public SubNavigation(Page rootPage, int levelToBeIncluded)
    {
        links = new LinkedList();
        buildLinkAndChildren(rootPage, 1, levelToBeIncluded);
    }

    private void buildLinkAndChildren(Page page, int level, int levelToBeIncluded)
    {
        if(page != null)
        {
            String title = page.getTitle();
            if(title == null)
                title = page.getName();
            if(level <= levelToBeIncluded)
            {
                links.add(new Link(page.getPath(), title, level));
                Page child;
                for(Iterator children = page.listChildren(new PageFilter()); children.hasNext(); buildLinkAndChildren(child, level + 1, levelToBeIncluded))
                    child = (Page)children.next();

            }
        }
    }

    public List getLinks()
    {
        return links;
    }

    private List links;
}
