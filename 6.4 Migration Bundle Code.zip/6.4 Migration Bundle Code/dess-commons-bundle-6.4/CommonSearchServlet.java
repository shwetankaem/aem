// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonSearchServlet.java

package com.dess.cq.common.servlets;

import com.dess.cq.common.helper.ConfiguredListService;
import com.dess.cq.common.search.SearchService;
import com.dess.cq.common.search.models.CommonSearchRequest;
import com.dess.cq.common.search.models.CommonSearchResultWrapper;
import java.io.IOException;
import java.io.PrintWriter;
import javax.jcr.RepositoryException;
import javax.servlet.ServletException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonSearchServlet extends SlingSafeMethodsServlet
{

    public CommonSearchServlet()
    {
    }

    public final void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
        throws ServletException, IOException
    {
        CommonSearchRequest commonSearchRequest = new CommonSearchRequest(request);
        LOGGER.info("Requested searchPath is: {} ", commonSearchRequest.getSearchPath());
        try
        {
            JSONObject jsonObject = null;
            CommonSearchResultWrapper commonSearchResultObject = null;
            if(commonSearchRequest.getListType() != null && (commonSearchRequest.getListType().equalsIgnoreCase("latestList") || commonSearchRequest.getListType().equalsIgnoreCase("relatedList")))
                commonSearchResultObject = getConfigureListService(commonSearchRequest);
            else
                commonSearchResultObject = getResultsFromService(commonSearchRequest);
            ObjectWriter ow = (new ObjectMapper()).writer().withDefaultPrettyPrinter();
            String jsonHitAsString = ow.writeValueAsString(commonSearchResultObject);
            jsonObject = new JSONObject(jsonHitAsString);
            LOGGER.info("Resultant JSON returned {}", jsonObject);
            response.setHeader("Content-Type", "application/json");
            response.getWriter().print(jsonObject);
        }
        catch(Exception exception)
        {
            LOGGER.error("Exception in CommonSearch Servlet: {}", exception);
        }
    }

    private CommonSearchResultWrapper getResultsFromService(CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        return searchService.getResults(commonSearchRequest);
    }

    private CommonSearchResultWrapper getConfigureListService(CommonSearchRequest commonSearchRequest)
        throws RepositoryException
    {
        return configuredListService.getConfiguredListResult(commonSearchRequest);
    }

    protected void bindSearchService(SearchService paramSearchService)
    {
        searchService = paramSearchService;
    }

    protected void unbindSearchService(SearchService paramSearchService)
    {
        if(searchService == paramSearchService)
            searchService = null;
    }

    protected void bindConfiguredListService(ConfiguredListService paramConfiguredListService)
    {
        configuredListService = paramConfiguredListService;
    }

    protected void unbindConfiguredListService(ConfiguredListService paramConfiguredListService)
    {
        if(configuredListService == paramConfiguredListService)
            configuredListService = null;
    }

    private static final long serialVersionUID = 0x2bfd609c6cb9ac08L;
    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/servlets/CommonSearchServlet);
    private transient SearchService searchService;
    private transient ConfiguredListService configuredListService;

}
