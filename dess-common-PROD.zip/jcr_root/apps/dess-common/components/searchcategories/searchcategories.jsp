<%--
  DESS Common | Search Categories Component
--%>
<%@include file="/apps/dess-common/components/global.jsp"%>
<%@page session="false"%>
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>
<%@taglib prefix="dess" uri="http://dess.co.in/desscommon"%>
<c:if test="${wcmEditMode}">
	<cq:includeClientLib
		categories="author.dess.common.components.searchcategories" />
</c:if>
<%List<Map<String, String>> valueMap= MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"multitermdesc");%>
<c:set var="labels" value="<%=valueMap%>"/>


<input id="currentnodepath" type="hidden" value="${currentNode.path}">
<input id="listcount" type="hidden" value="${properties.listcount}">
<input id="contentpath" type="hidden" value="${properties.contentpath}">
<cq:includeClientLib categories="handlebars" />
<div class="search-category-component">
	<div class="panel">
		<div class="panel-body">
			<form id="jsSearchByCat" class="form-wrapper form-horizontal form-category"
				role="search">
				<fieldset>
					<legend>${properties.legend}</legend>
					<c:set var="tagiterator" value="${dess:getChildTagsIterator(properties.connectto,resourceResolver)}" />
					<%-- THis dropdown is always visible --%>
					<div class="form-group">
						<label class="col-md-4 col-sm-4 control-label" for="selectProduct">Product
							location</label>
						<div class="col-md-5 col-sm-5">
							<select id="selectProduct" name="selectProduct"
								class="form-control">
								<optgroup label="">
								<option value="ukpaw-locations:uk" selected>United Kingdom</option>
								<option value="ukpaw-locations:ie">Ireland</option>
								</optgroup>
							</select>
						</div>
					</div>
					
					<div class="form-group">
                      <label class="col-md-4 col-sm-4 control-label" for="selectProduct">${labels[0]['term']}</label>
                      <div class="col-md-5 col-sm-5">
                        <select id="selectProductType" name="selectProduct" class="form-control">
                          <optgroup label="">
                            <option value="all" selected>${labels[0]['desc']}</option>
                            <c:forEach varStatus="vs" items="${tagiterator}" var="tag">
							<option value="${tag.tagID}">${tag.title}</option>		
							</c:forEach>
                            </optgroup>
                        </select>
                      </div>
                    </div>
<script id="search-category" type="text/x-handlebars-template">
                    <div class="form-group">
                      <label class="col-md-4 col-sm-4 control-label" for="selectProductType">{{label}}</label>
                      <div class="col-md-5 col-sm-5">
                        <select name="selectProductType" class="form-control">
                          <optgroup label="">
						    {{#each tagList}}
        					 <option {{#if selected}} selected {{/if}} value="{{tagID}}">{{tagTitle}}</option>
                          	{{/each}}
                          </optgroup>
                        </select>
                      </div>
                    </div> 
</script>
					<div class="form-group">
						<label class="sr-only col-md-4 col-sm-4 control-label"
							for="singlebutton">Single Button</label>
						<div class="col-md-5 col-sm-5">
							<button id="jsResultsButton"
								class="btn btn-primary btn-large btn-block btn-search icon-lg">
								${properties.submitbtntext}
								<span class="icon icon-arrow-right"></span>
								<%-- Used for counting results count based on selection from dropdowns - starts with full available results count--%>
								<span class="result-amount"></span>
							</button>
						</div>
					</div>

				</fieldset>
			</form>
		</div>
	</div>
	<%-- /Panel-body --%>


<div class="search-category-results">
	<div id="jsResultsHeader" class="col-sm-12 col-md-12 col-lg-12">
	</div>
	<div class="row filter-vertical">
		<div class="col-xs-12">
			<div id="jsLoadingSpinner" class="ajax-loading hidden" role="alert"
				aria-live="polite">Loading results</div>
			 <ul id="resultsList" class="list-items" aria-live="polite">
			 </ul>
			 <ul class="pager" aria-hidden="true">
			 </ul>
		</div>
	</div>
</div>
</div>
<%-- / search-category-component --%>
<script id="search-header-template" type="text/x-handlebars-template">
     <h3>{{totalMatches}} Results</h3>
     <hr class="hr-light-gray">
</script>
<%-- Results --%>
<script id="search-results-template" type="text/x-handlebars-template">
    <%-- ACTION - Investigate use of aria-live - Should be used when ajax or other methods change the content of the page without refresh --%>
  
    {{#each results}}
     <li>
       <a href="{{resultPath}}" class="{{resultClass}}" target="{{target}}">
         <span class="list-item-title">{{resultTitle}}</span>
		 {{#if isAsset}}
		  <span class="sr-only">(Opens in a new window)</span>
		  <span class="sr-only"> - </span>
		  <span class="list-item-info">{{docType}} ({{assetSize}}{{unit}})</span>
		 {{/if}}
		{{#if resultDescription}}
		  <span class="list-item-short-desc">{{resultDescription}}</span>
		{{/if}}
       </a>
     </li>
     {{/each}}
</script>
<script id="search-pager-template" type="text/x-handlebars-template">
	
     {{#if disablePrevButton}}
     	<li class="previous disabled"><a href="#" arria-hidden="true"><span class="icon icon-arrow-left"></span>Prev<span class="sr-only">ious set part of results</span></a></li>
	  {{else}}
	  	<li class="previous"><a href="{{previousPageAjaxUrl}}" arria-hidden="true"><span class="icon icon-arrow-left"></span>Prev<span class="sr-only">ious set part of results</span></a></li>
	  {{/if}}
     <li class="count">{{currentPageIndex}} of {{totalPages}}</li>
	  {{#if disableNextButton}}
     	<li class="next disabled"><a href="#">Next<span class="sr-only"> set part of results</span><span class="icon icon-arrow-right"></span></a></li>
	  {{else}}
		<li class="next"><a href="{{nextPageAjaxUrl}}">Next<span class="sr-only"> set part of results</span><span class="icon icon-arrow-right"></span></a></li>
	  {{/if}}

</script>
