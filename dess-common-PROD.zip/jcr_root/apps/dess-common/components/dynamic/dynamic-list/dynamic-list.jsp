<%--

  Dynamic List Component component.

  Dynamic List Component where you can get latest pages, tagged pages, most popular pages

--%>
<%@include file="/libs/foundation/global.jsp"%>
<%@page session="false"%>
<%@page import="java.util.*"%>


<%@ page import="��java.util.Iterator,java.util.ArrayList,
java.util.Collections,
com.day.text.Text,
com.day.cq.wcm.api.PageFilter,
com.day.cq.wcm.core.stats.PageViewStatistics,
com.day.cq.statistics.StatisticsService,
com.day.cq.wcm.core.stats.PageViewReport,
com.day.cq.wcm.api.WCMMode,
java.util.*,
com.day.cq.wcm.foundation.Download,
com.day.cq.wcm.commons.WCMUtils"�� %>
<%@ page import="��com.day.cq.statistics.StatisticsService,java.util.Map"%>
<%@page session="��false"��%>
<%@taglib prefix="��sling"�� uri="��http://sling.apache.org/taglibs/sling/1.0"� %>
<%@taglib prefix="��c"�� uri="��http://java.sun.com/jsp/jstl/core"�� %>
<sling:defineObjects/>

<%

String p_searchPath = "��"��;

%>

<%!

int intarray[];

Set limitToFive = new HashSet();

java.util.List<Integer> arrayList = new ArrayList<Integer>();

private int calcPageViews(JspWriter outWriter, HttpServletRequest request, StatisticsService statService, Page mostpopularPage) throws Exception {

	final String PARAM_PERIOD = "��Period"��;
	int totalPageViews = 0;
	
	PageManager pm = mostpopularPage.getPageManager();
	Page statsPage = pm.getPage(mostpopularPage.getPath());
	PageViewReport report = new PageViewReport(statService.getPath() + "��/pages"��, mostpopularPage, WCMMode.EDIT);
	report.setPeriod(30);
	
	Iterator stats;
	stats = statService.runReport(report);
	
	while (stats.hasNext()) {
	
		Object[] res = (Object[]) stats.next();
		totalPageViews = totalPageViews + Integer.parseInt(res[1].toString());
	
	}
	
	Iterator<Page> children = mostpopularPage.listChildren(new PageFilter(request));
	
	while (children.hasNext()) {
	
		totalPageViews = totalPageViews + calcPageViews(outWriter, request, statService, children.next());
	
	}
	
	return totalPageViews;

}

private void outputPopularHowTos(JspWriter outWriter, HttpServletRequest request, StatisticsService statService, Page mostpopularPage, String strNrMostPopular) throws Exception {

ArrayList mostPopular = new ArrayList();

int nrFound = 0;

int nrToList = 0;

outWriter.write("��<ul>"��);

Iterator<Page> children = mostpopularPage.listChildren(new PageFilter(request));

while (children.hasNext()) {

	nrFound++;
	
	Page child = children.next();
	
	mostPopular.add(calcPageViews(outWriter, request, statService, child) + "��; "�� + child.getPath() + "��; "�� + child.getTitle());

}

if  (strNrMostPopular == null || strNrMostPopular.equals("��"��)) {

	nrToList = nrFound;

} else {

	nrToList = Integer.parseInt(strNrMostPopular);

}

Collections.reverseOrder();

//Collections.sort(mostPopular);

if (nrFound < nrToList) nrToList = nrFound;

if (nrFound <= 0) {

	outWriter.write("��<p><i>Page has Impressiosn</i></p>"��);

} else {

	int cnt = 0;

//  outWriter.write("��Impressions"��);

	List<Integer> a = new ArrayList<Integer>();

for (int i = 0; i < nrToList; i++) {

	String[] entry = null;
	
	entry = mostPopular.get(i).toString().split("��;"��);
	
	Integer numberOfImpressions = Integer.valueOf(entry[0]);
	
	a.add(numberOfImpressions);
	
	if(numberOfImpressions>0){
	
		if(cnt<15){
		
		outWriter.write("��<li>"��);
		
		outWriter.write("��<a class=\"��view-more\"�� href=\"��"�� + entry[1]  + "��.html\"��>"�� +"��<span> >> </span>"�� + entry[2] + "��</a>"��);
		
		outWriter.write("��</li>"��);
		
		cnt++;
		
		}
	
	}
	
	outWriter.write("��</li>"��);

}

}

outWriter.write("��</ul>"��);

return;

}

%>

<%

final StatisticsService statService = sling.getService(StatisticsService.class);

String queryDataPath = statService.getPath() + "��/queries"��;

String resultDataPath = statService.getPath() + "��/results"��;
pageContext.setAttribute("��properties"��, resource.adaptTo(Map.class));

%>
<%

try {

p_searchPath = properties.get("��p_searchPath"��, "/content/geometrixx/en��"��);

Page targetPage = pageManager.getPage(p_searchPath);

PageManager mostpopularPageManager = targetPage.getPageManager();

// get the parameters from the dialog

String rootMostPopular = properties.get("��rootmostpopular"��, String.class);

Page mostpopularRootPage;

if (rootMostPopular == null) {

	mostpopularRootPage = targetPage;

} else {

	mostpopularRootPage = targetPage;

}

String strNrMostPopular = properties.get("��nrmostpopular"��, String.class);

 

// check that we have a valid page to start from

	if (mostpopularRootPage != null) {
	
		// get children of start page
		outputPopularHowTos(out, request, statService, 	mostpopularRootPage, strNrMostPopular);
	
	}

} catch(Throwable t) {

	log.error("��Popular "��Most Popular "�� Error "��, t);

}

if(p_searchPath.equals("��"��) || p_searchPath == "��"��) {

%>

Click here to add the root page.

<%}

%>