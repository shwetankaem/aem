// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TagUtility.java

package com.dess.cq.common.utilities;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import javax.jcr.*;
import javax.servlet.ServletResponse;
import javax.servlet.jsp.PageContext;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TagUtility
{

    public TagUtility()
    {
    }

    public static void getChildTagsAsJSON(PageContext context, String tagID)
    {
        ResourceResolver resourceResolver;
        if(tagID.isEmpty())
            return;
        resourceResolver = ((SlingHttpServletRequest)context.getRequest()).getResourceResolver();
        Iterator tagI = getChildTagsIterator(tagID, resourceResolver);
        if(tagI == null)
        {
            resourceResolver.close();
            return;
        }
        String path = ((SlingHttpServletRequest)context.getRequest()).getRequestPathInfo().getResourcePath();
        Value labelDesc = getLabelDescValue(resourceResolver, tagID, path);
        JSONObject jsonObject = new JSONObject();
        JSONObject tagObject = null;
        JSONArray jsonArray = new JSONArray();
        JSONObject json = new JSONObject(labelDesc.getString());
        jsonObject.put("label", json.get("term"));
        tagObject = new JSONObject();
        tagObject.put("tagID", "all");
        tagObject.put("tagTitle", json.get("desc"));
        tagObject.put("selected", true);
        jsonArray.put(tagObject);
        Tag tag = null;
        for(; tagI.hasNext(); jsonArray.put(tagObject))
        {
            tag = (Tag)tagI.next();
            tagObject = new JSONObject();
            tagObject.put("tagID", tag.getTagID());
            tagObject.put("tagTitle", tag.getTitle());
        }

        jsonObject.put("tagList", jsonArray);
        if(jsonArray.length() > 1)
            context.getResponse().getWriter().print(jsonObject);
        else
            context.getResponse().getWriter().print("");
        resourceResolver.close();
        break MISSING_BLOCK_LABEL_384;
        IOException ioException;
        ioException;
        LOGGER.error("Could not convert to JSON :: {}", ioException.getMessage());
        resourceResolver.close();
        break MISSING_BLOCK_LABEL_384;
        JSONException jsonException;
        jsonException;
        LOGGER.error("Could not convert to JSON :: {}", jsonException.getMessage());
        resourceResolver.close();
        break MISSING_BLOCK_LABEL_384;
        RepositoryException repositoryException;
        repositoryException;
        LOGGER.error("Could not convert to JSON :: {}", repositoryException.getMessage());
        resourceResolver.close();
        break MISSING_BLOCK_LABEL_384;
        Exception exception;
        exception;
        resourceResolver.close();
        throw exception;
    }

    public static Iterator getChildTagsIterator(String tagID, ResourceResolver resourceResolver)
    {
        TagManager tagManager = (TagManager)resourceResolver.adaptTo(com/day/cq/tagging/TagManager);
        Tag tag = tagManager.resolve(tagID);
        if(tag == null)
            return null;
        else
            return tag.listChildren();
    }

    private static Value getLabelDescValue(ResourceResolver resourceResolver, String tagID, String path)
        throws RepositoryException
    {
        Node node = (Node)resourceResolver.getResource(path).adaptTo(javax/jcr/Node);
        TagManager tagManager = (TagManager)resourceResolver.adaptTo(com/day/cq/tagging/TagManager);
        Tag tag = tagManager.resolve(tagID);
        Property a = node.getProperty("connectto");
        String connecttoPath = a.getValue().getString();
        int depth = tag.getPath().split("/").length - connecttoPath.split("/").length;
        Property multiProp = node.getProperty("multitermdesc");
        return multiProp.getValues()[depth];
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(com/dess/cq/common/utilities/TagUtility);

}
