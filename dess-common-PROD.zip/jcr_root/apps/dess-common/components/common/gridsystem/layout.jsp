<%@include file="/apps/dess-common/components/global.jsp"%><%
%>
<%@page import="com.dess.cq.common.utilities.widgets.MultiFieldPanelFunctions"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>
<%@page session="false" %>

<%
List<Map<String, String>> valueMap= MultiFieldPanelFunctions.getMultiFieldPanelValues(resource,"multitermdesc");
final String[] layoutCountNClass=properties.get("layoutvalue","2#2/3-2/3-1-1").split("#");
%>
<c:set var="columnValues" value="<%=valueMap%>" />

<c:if test="${properties.rowactivateid}">
<c:set var="idAttrRow" value="id=\"${properties.rowid}\""/>
</c:if>


<c:choose>
<c:when test="${fn:length(columnValues) > 0}">
<c:set var="layoutCount" value="<%=layoutCountNClass[0]%>"/>
<c:set var="layoutClass" value="<%=layoutCountNClass[1]%>"/>

<c:choose>
<c:when test="${!fn:contains(layoutClass,'2/3-2/3-1-1')}">
<dess:cleanHTMLFragment> 
<${properties.rowhtml5tag} class="row ${properties.rowclassappends} ${properties.rowshowonprint eq 'true'?'':'hidden-print'}" ${idAttrRow}>
</dess:cleanHTMLFragment> 
<c:forEach varStatus="vs" items="${columnValues}" var="columnValue">

<c:if test="${columnValue['activateid']}">
<c:set var="idAttrColmn" value="id=\"${columnValue['mcolumnid']}\""/>
</c:if>
<dess:cleanHTMLFragment> 
<${columnValue['mhtml5tag']} ${idAttrColmn} class="${empty columnValue['mcssoverride']?layoutClass :columnValue['mcssoverride']}"> 
</dess:cleanHTMLFragment> 
<cq:include path="column-${vs.count}" resourceType="foundation/components/parsys" />
    </${columnValue['mhtml5tag']}>
    <c:if test="${columnValue['misclearfix']}">
		<div class="${columnValue['mcssclearfix']}"></div>
	</c:if>
</c:forEach>
</${properties.rowhtml5tag}>
</c:when>

<c:otherwise>
<dess:cleanHTMLFragment>     
<${properties.rowhtml5tag} class="row ${properties.rowclassappends}" ${idAttr}>
</dess:cleanHTMLFragment>     
<c:forEach varStatus="vs" items="${columnValues}" var="columnValue">

<c:if test="${columnValue['activateid']}">
<c:set var="idAttrColmn" value="id=\"${columnValue['mcolumnid']}\""/>
</c:if>
<c:if test="${vs.count == 1}">
<dess:cleanHTMLFragment> 
<${columnValue['mhtml5tag']} ${idAttrColmn} class="${empty columnValue['mcssoverride']?'col-sm-12 col-md-8 col-lg-8':columnValue['mcssoverride']}">
</dess:cleanHTMLFragment> 
		<cq:include path="column-1" resourceType="foundation/components/parsys" />

</${columnValue['mhtml5tag']}>
</c:if>
<c:if test="${vs.count == 2}">
	<dess:cleanHTMLFragment>
    <${columnValue['mhtml5tag']} class="${empty columnValue['mcssoverride']?'col-sm-12 col-md-4 col-lg-4':columnValue['mcssoverride']}">
    </dess:cleanHTMLFragment>
        	<cq:include path="column-2" resourceType="foundation/components/parsys" />

        </${columnValue['mhtml5tag']}>
</c:if>
        <c:if test="${columnValue['misclearfix']}">
			<div class="${columnValue['mcssclearfix']}"></div>
		</c:if>
</c:forEach>
</${properties.rowhtml5tag}>
</c:otherwise>
</c:choose>
</c:when>
<c:otherwise>
    <h4>Edit Grid System</h4>
</c:otherwise>
</c:choose>    

